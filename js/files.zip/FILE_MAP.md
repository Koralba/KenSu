# 中職野球2027 — 檔案地圖（給 AI／開發者）

純前端、無打包：`baseball.html` 依序載入 `css/*.css` 與 `js/*.js`。
**所有 JS 共用同一個全域作用域**（classic script，不是 ES module）：頂層的 `const/let/function` 彼此可直接呼叫，不用 import/export。

## 規則（重要）
1. **載入順序＝檔名編號**，不可調換（頂層會立即執行的程式依賴前面檔案已定義的東西）。
2. 函式只在「執行時」才呼叫其他檔的函式，所以新增函式放哪個檔都能被呼叫；但**頂層立即執行的語句**只能用「編號較小的檔」裡的東西。
3. `14-bullpen-loop-boot.js` 結尾的 `boot()` 會啟動遊戲 → **新增檔案請插在 13g 與 14 之間**（編號用 13h、13i…），在 baseball.html 加一行 `<script src="js/13h-xxx.js"></script>`，並在檔頭加 `'use strict';`。
4. `mkRng`（653 起的 03 檔與 04 檔各有一份）、`practiceSwing`（11 與 13 檔各有一份）是原檔就有的**同名重複**，後載入者生效，**不要改動或刪除**（保持行為與原版一致）。
5. **新增任何 css/js/images 檔，必做三件事**：①`baseball.html` 加載入標籤；②`sw.js` 的 `LOCAL` 清單加路徑；③`sw.js` 的 `VERSION` 數字 +1（否則已安裝的玩家拿不到新檔，離線時還可能缺檔）。
6. CSS 是「補丁式堆疊」，後面的規則會覆蓋前面的；要覆蓋既有樣式，新規則放在最後（04）或新建 `css/0N-xxx.css` 並接在最後一個 css 之後載入。

## JS（依載入順序）
| 檔案 | 內容 | 修改時機 |
|---|---|---|
| `01-core-data.js` | 工具函式(clamp/rnd/pick…)、球場尺寸、`PITCHES` 球種、`TEAMS` 球隊球員資料、能力值換算(F～S)、心情值 | 改球員／球隊／能力值 |
| `02-stadium-scene.js` | three.js 場景：草皮、內野、全壘打牆看板、觀眾、夜間燈光（`lightPool` 場地光池、燈塔 `halo` 光暈、`BEAM_MAT`、`RIM`、燈頭顏色都是「加法混色」的疊加光，太亮會把畫面洗成死白，目前已調低偏暖；**場景主光 `hemi`／`sun`／`flood1~3` 的強度不在這個檔**，是別的檔在執行時設定，夜間整體亮度要去那裡調） | 改球場外觀 |
| `03-players-ball-camera.js` | Q版球員外觀／打擊投球姿勢／落地修正／球／擊球特效／煙火／止滑粉／鏡頭 | 改球員模型、鏡頭 |
| `04-pitch-swing-physics.js` | **`G` 遊戲狀態**、實體、投球模型、揮棒／擊球判定、球的物理、擊球軌跡 | 改投打手感 |
| `05-play-fielding-runners.js` | 球進場內：守備計畫、傳球、跑者、觸殺、出局 | 改守備／跑壘 |
| `06-play-abs-update.js` | ABS 跑壘／全壘打判決、接殺、每幀 play 更新、手動傳球 | 改判決與場內每幀邏輯 |
| `07-cpu-ai.js` | 電腦：站位、配球、打擊、盜壘、牽制、換人 | 改 AI 難度 |
| `08-audio.js` | `$` 取元素工具、WebAudio 音效、背景音樂、擊球／觀眾音效；檔尾 `AUTOSIM_FF_GUARD` 區塊：快轉（`window.__ff`）時所有發聲函式直接略過 | 改音樂音效 |
| `09-hud-commentary.js` | HUD 輔助、實況文字、主播＋球評 | 改畫面資訊／播報 |
| `10-events.js` | ABS 鷹眼挑戰、觸身球衝突、驅逐、傷退換人、沒收比賽 | 改特殊事件 |
| `11-game-flow.js` | 開賽介紹、半局／投球循環／打席結果、球棒事件、引擎 hooks、`endGame()` | 改比賽流程、結算（**生涯模式主要接點**） |
| `12-systems.js` | 天氣風力、暴雨、台灣天氣、心情事件、教練上場、傷病、擊球資訊面板 | 改天氣／狀態系統 |
| `13-ui-input-menu.js` | overlay、輸入、投球準度條、返回主選單、代打代跑、`toGame()`、`CFG` 比賽設定、`launchGame()`、賽前編成、戰術／守備面板、音樂面板 | 改選單／輸入／賽前編成 |
| `13b-save-system.js` | **存檔／讀檔**：3 個欄位（一般／生涯各 3 格）、匯出／匯入 .json、**存檔同時寫入裝置檔案**（電腦 Chrome／Edge 每欄位一個檔案並自動更新，檔案代碼存 IndexedDB `cpbl_guard`；開關 localStorage `cpbl_filesave`；手機走分享／下載；讀檔畫面開啟時自動同步較新的檔案）、`SAVE.hooks.career` 生涯接點；包住 `startHalf`（每半局開始記檢查點）與 `uiHold`（視窗開著時暫停） | 改存檔內容、欄位數、存檔視窗 |
| `13n-storage-guard.js` | **存檔保護**：要求持久儲存、整個 localStorage 備份／還原成檔案（電腦可選位置並自動寫入、手機走分享／下載）、超過 3 天沒備份的提醒；不依賴 13b 的格式（載入在 13l 之後、14 之前） | 改備份流程 |
| `13o-update-check.js` | **自動更新**：只在剛進主畫面時比對一次（不輪詢）；標題右下按鈕可手動再查。比對 `sw.js` 的 VERSION，有新版就顯示頂部跑馬燈、標題／選單時自動重新載入（比賽中不打斷）；卡住 20 秒會清 Cache Storage＋登出 SW 後重載。**不動 localStorage／IndexedDB（存檔在那裡）**。標題畫面右下有「🔄 檢查更新」（雙擊＝強制更新）。測試：`tests/test-update-check.js`（第二十二版已改寫，14 項，會真的執行斷言） | 改更新流程 |
| `13p-lan-versus.js` | **雙人區網對戰**：`VS` 物件。WebRTC DataChannel 直連（同 Wi-Fi、免伺服器），邀請碼／回覆碼或 QR 配對；兩台各跑相同模擬（固定 1/60 步長、同種子亂數、鎖步），房主權威校正；投球限時 15／18 秒；大廳設定（局數、先攻、球場、輔助、簡易、天氣、ABS）。對戰中 `body` 加 `vsx`。QR 元件 `js/vendor/qrcode.min.js`（產生）與 `js/vendor/jsqr.min.js`（掃描）由本檔**動態載入**（不在 `baseball.html`，但在 `sw.js` LOCAL）。詳見文末兩段區網對戰說明。測試：`tests/test-lockstep.js`（路徑需修正）、`tests/test-webrtc-pairing.js` | 改區網對戰、配對、同步、大廳 |
| `13q-strikeout-fx.js` | **三振強化** `KFX`：投手 K 數（`p.kx`）、三振慢動作回放（錄投手／捕手／打者／主審姿勢＋球，三振後約 1 秒凍結 `G.freeze` 用 3 機位重播）、空揮特效 `KFX.whiff()`、被三振懊惱動作 `KFX.react()`（摔棒／折棒／丟棒／跺腳／搖頭／敲地，棒子是 3D 物件含簡易物理）。區網對戰／快轉／練習停用。見文末「三振強化（第 N 版）」 | 改三振回放、懊惱動作 |
| `13c-career-create.js` | **生涯模式 第一階段**：`CAREER` 物件。角色欄位（3 格）、建立／編輯角色與外觀、頭像／球員卡、角色匯出匯入；欄位上的「▶ 開始生涯」呼叫 `CSEASON.begin()`；`CAREER.session` ＝目前生涯比賽的角色 | 改角色欄位、角色編輯器、球員卡 |
| `13d-career-season.js` | **生涯模式 第二階段**：`CSEASON` 物件。虛構社會組球隊產生器、把角色放進球隊、依位置操控、每場成績紀錄、選秀評分與抽籤、落選後「上班族一年」循環、`SAVE.hooks.career` 賽季資料 | 改生涯流程、對手強度、選秀規則、場數／局數 |
| `13e-career-pro.js` | **生涯模式 第三階段**：`CPRO` 物件。選上中職後的職業賽季：仿中職 120 場賽程產生器（系列戰、輪轉法）、其他隊比賽模擬與戰績表、板凳候補起步＋信賴度／升先發、比賽中叫上場（`benchCall`／`bullpenCall`）、賽程／戰績畫面 | 改職業賽季、賽程規則、出場機制 |
| `13f-career-autosim.js` | **生涯模式：自動模擬**。`AUTOSIM` 物件：偏好為開時，「不是輪到你」就用 `window.__ts` 快轉並顯示計分板／壘包／出局數特殊畫面（`#asPanel`），輪到你（`humanBats/humanPitches/PL.ask`）自動恢復，隨時可用「👁 恢復觀看」／右上角「⏩ 自動模擬」切換；快轉時 `window.__ff=true`，14 的 `frame()` 不繪製、不調畫質 | 改自動模擬、快轉速度、特殊畫面 |
| `13g-manual-fielding.js` | **手動守備**：`FM` 物件。玩家守備時，球打出後自動選取離球最近的守備員，方向鍵／手機方向盤走位撿球（相對畫面方向）、其他守備員頭上有半透明按鈕可換人、撿到球後可繼續走動再用傳球面板選壘；「輔助防守」開＝維持原本電腦自動追球。生涯模式只能操控自己的角色 | 改手動守備手感、換人按鈕、輔助防守 |
| `13h-career-story.js` | **生涯劇情事件引擎**：`CSTORY`（資料驅動：條件／選項／效果／旗標／防重複／存讀檔）＋46 個事件（含交友 6 個；賽季／季後賽／例行賽中段／多年度／第 3～15 年主線／退役選擇，phase：pro_start／after_game／season_end／po_series／po_end／offseason）。**只靠 ctx／adapter，不碰其他檔的全域**；由 `13e` 的 `storyGate()` 在 `showIntro()`／`showEnd()`（選單畫面，不在比賽／快轉中）呼叫，事件狀態存 `SS.pro.story`（跟 13d `saveSeason()` 整包存）。可在 Node 單獨測：`node tests/test-career-story.js` | 改劇情事件、觸發條件、選項效果 |
| `13i-career-economy.js` | **生涯經濟（A1）**：`CECON` 純邏輯。薪水／存款／體能／心情／運動設備（0～5 級）／商店（吃飯、約會、設備升級，有次數與等級上限）／休賽季結算（領年薪、扣生活費）／`trainMult()` 訓練效果倍率（0.85～1.45，只乘在信賴度的「正向」成長上）。狀態存 `SS.pro.money／fit／mood／gear／shop／econ`；舊存檔缺欄位由 `ensure()` 補預設。**13e 沒載入 13i 時整段略過**。Node 測試：`node tests/test-career-economy.js` | 改薪水公式、商店項目與價格、訓練倍率 |
| `13j-catcher-call.js` | 捕手配球 `CCALL`（見「生涯模式守備／捕手配球」段） | 改捕手配球面板 |
| `13k-story-scenes.js` | **劇情／總選單插畫** `CSCENE`：內嵌 SVG（640×240，無外部圖檔、離線可用）。`S`＝場景、`BY_ID`＝事件／總選單分頁 → 場景、`CAP`＝圖說；沒對應的事件依 phase 取預設。共 25 個場景（原 19＋第二批 6：coachroom／outfield／locker／snack／stands／calendar）。測試：`node tests/test-story-scenes.js` | 改插畫、新增場景 |
| `13l-abs-camreplay.js` | ABS 多鏡頭慢動作回放（見「ABS 跑壘挑戰」段） | 改回放 |
| `13m-career-hub.js` | **生涯總選單 HUB** `CHUB`（見「生涯總選單 HUB」段）：七個分頁（主畫面／賽程／訓練休息／交友／交易合約／消費／戰績）、賽程月曆、休兵日行動畫面 | 改總選單畫面 |
| `13t-face-expression.js` | **球員表情系統** `FACE`：包住 `eyeVariant／addFace／makeChibi／rigStep`，加一層表情層（眼白＋虹膜＋瞳孔＋高光、眼瞼眨眼／瞇眼、可動眉毛、畫布嘴型、臉紅／汗／淚／青筋），依 `rig.anim.name`（`FX_ANIM`）自動切換 31 種表情（`FACE.table`）；遠景自動降級、快轉不更新、自己的亂數。載入在 13s 之後、14 之前。對外：`FACE.emote(rig,'angry',1.5)`、`FACE.all('laugh',3)`。關閉：`FACE.on=false` | 改表情、眼睛／嘴型外觀 |
| `14-bullpen-loop-boot.js` | 牛棚熱身、主迴圈 `frame/step`（快轉時不繪製、且 `step` 迴圈內一輪到玩家就中斷）、`boot()`、全螢幕、**主畫面（一般／生涯／區網對戰／離開，`#tmCareer`；`#tmVersus` 由 13p 綁定）**、標題特效；區網對戰時（`vsOn()`）`frame()` 改固定 1/60 步長 | 改主畫面入口、主迴圈 |

## 生涯劇情事件（13h＋13e 的 storyGate）
- **載入**：已列入 `baseball.html`（13g 後、14 前）與 `sw.js`（`VERSION` v15）。13e 若沒載入 13h（`typeof CSTORY==='undefined'`）整段略過，不影響賽季。
- **觸發點（皆在 13e）**：`showIntro()` 開頭 → `pro_start`（賽季第一場前）、`after_game`（每場結束後，含「直接出結果」與正常打完回到選單）；`showEnd()` 開頭 → `after_game`（最後一場）、`season_end`。**只在選單畫面檢查，所以不會被自動模擬／快轉衝掉**。
- **檢查點存在 `SS.pro`**：`storyStart`（開季事件已檢查）、`storyChk`（上次檢查時的已打場數）、`storyEnd`；`SS.pro.story`＝`CSTORY` 狀態（flags／seen／rel／log）。事件看完前就離開（返回主畫面），下次進賽前畫面會再出現同一事件。
- **ctx（13e 的 `storyCtx()`）**：`year`＝`P.year||1`（多年度；`po`／`team.champion` 只在季後賽期間提供）、`gameNo`＝`P.log.length`、`starter`、`apps`、`trust`、`lastGame.played`、`team:{}`。**刻意不提供 `team.playoffQualified`**：季後賽賽制未實作前，季後賽／球季檢討事件不會出現。
- **adapter**：只有 `trust`（0～100）。引擎遇到遊戲沒有的數值（疲勞、士氣…）會略過，不新增欄位；關係值（coach／veteran／team）與旗標存在 `story` 狀態裡，目前只存不影響比賽。
- **新增事件**：在 13h 用 `register({ id, phase, title, text[], conditions[{field,operator,value}], once_per_career／once_per_season／cooldown_games, priority, choices[{id,label,hint,effects[],result[]}] })`；文字可用 `{team}`、`{name}`。同一時間點一次只彈一個、最多連續 3 個。
- **`team.playoffQualified` 已提供**：13e 的 `storyCtx()` 在例行賽全部打完時才給（`playoffField().qualified` 含我方球隊＝true），所以 `PRO_PLAYOFF_PUSH`（晉級）與 `PRO_SEASON_REVIEW`（未晉級）依 114 年賽制自動啟用；沒打完時不提供 → 不誤播。`year` 仍固定 1（多年度時再改）。
- 驗證：`tests/test-career-story.js` 27 項（引擎邏輯）；另有假環境載入真正 13e 的整合測試（開季事件→選擇→存檔→120 場快速模擬）通過；**尚未在瀏覽器實機驗證**。

## 114 年（中職 36 年）賽制（13e：`tally`／`decideField`／`playoffField`／`fieldHtml`）
- **半季**：每隊第 1～60 場＝上半季、第 61～120 場＝下半季（`HALF=60`；以每隊場次序號切分，非日期；半季場數是由 120 場推得，**未逐條查證官方規章**）。
- **名單判定（依 2025 年網路報導，非官方規章原文）**：①上下半季冠軍不同隊 → 全年勝率較高者直通台灣大賽（7 戰 4 勝、5 場主場）；較低者＋「兩半季冠軍以外全年勝率最高」者打季後挑戰賽（5 戰 3 勝，半季冠軍先取 1 勝、G1/G3/G4 主場）。②同隊包辦 → 該隊直通；全年第 2 對第 3 打挑戰賽，第 2 名 3 場主場（**報導未提保送 1 勝，程式設 0，待確認**）。
- **同勝率排序**：官方規則未查到，簡化為「得失分差 → 球隊編號」。
- **已做（名單）**：賽季結算畫面（`showEnd`）顯示賽制結果；`SS.pro.field` 存名單；晉級才觸發季後賽劇情事件。
- **已做（季後賽實際比賽，13e 的 `poBegin／showPO／poAdvance／poRecord／poSettle／poFinish`）**：結算畫面晉級球隊有「🏆 前往季後賽」→ 季後挑戰賽 → 台灣大賽。狀態 `SS.pro.po = {active,done,stage,ser,chWinner,champ,out,hist[]}`，你的出賽紀錄在 `SS.pro.poLog`（**不混進**例行賽 `log`／`apps`）；比賽 id 為字串 `po-<stage>-<第幾戰>-<已打場數>`，物件帶 `po:true`。`curGame()`＝季後賽期間回傳季後賽下一場（13e 的 `inject`／`afterEnd` 都改用它）；季後賽期間 `SS.pro.active` 保持 true，所以 13d 仍把 `inject`／`afterEnd` 轉給 13e（**13d 沒改**）。你沒參賽或被淘汰後，其餘場次由 `simGame()` 自動模擬（和局重抽；你打出的和局不計、重打）。`finish()` 拆出 `growth()`（信賴度／先發升降），例行賽與季後賽共用。
- **主客場（依 2025 年報導）**：挑戰賽有保送勝：半季冠軍 G1/G3/G4、外卡 G2（4 場內決勝，先取 3 勝含保送 1 勝）；台灣大賽 7 戰 4 勝：直通隊 G1/G2/G5/G6/G7、挑戰賽勝者 G3/G4。**同隊包辦（無保送勝）的 5 戰主場順序未查到，暫設 第2名 G1/G2/G5**。
- **多年度（第五版）**：賽季（含季後賽）結束後出現「📝 續約，進入第 N 年」→ 先播 `offseason` 續約事件 → `CPRO.nextYear()`：`P.hist` 存本季摘要、`P.year`+1、新 seed、清空 res／log／apps／po／field 與劇情檢查點，保留球隊／信賴度／先發身分／`P.story`。**未做**：球隊異動／選秀重抽、年齡與退役結局、15 年主線事件、獎項、合約系統。
- 測試：`tests/test-career-integration.js`（TEAM／SEED 環境變數可換隊伍與種子；晉級 39 項、未晉級 25 項；6 隊×3 種子共 18 個整季皆通過）。**只用「直接出結果」（quick）跑過季後賽；真的進場比賽（launch→afterEnd）的路徑沒在瀏覽器驗證**。

## 測試腳本（`tests/` 資料夾）
- **不屬於遊戲**：`baseball.html` 不載入、`sw.js` 不快取，玩家用不到；只給開發者在電腦上用 Node.js 檢查邏輯。不上傳 GitHub 也不影響遊戲運作（建議一起放進去，方便之後重跑）。
- **執行**：在專案根目錄用 `node tests/<檔名>.js`（Windows PowerShell 換變數：`$env:TEAM=3; $env:SEED=222; node tests/test-career-integration.js`）。多數測試用「測試檔自己的位置」找 `../js/`，在根目錄或 `tests/` 內都能跑；**`test-update-check.js` 用相對路徑 `sw.js`、`js/13o-update-check.js`，一定要在專案根目錄跑**。
- **這些都是假環境（vm＋假 DOM／假引擎）的邏輯測試，不代表瀏覽器實機已驗證。**
- **2026-10-27 實跑結果（Node v22，用本次上傳的全部 js／css 檔）**

| 測試檔 | 結果 | 說明 |
|---|---|---|
| `test-career-story.js` | 45／45 ✔ | 13h 劇情引擎（事件數 46） |
| `test-career-integration.js` | 83 項 ✔ | 真 13e＋13h：整季、114 年賽制、季後賽、存讀（晉級與否分支項數會在 63／83 間變動） |
| `test-career-economy.js` | 20／20 ✔ | 13i 純邏輯（薪水、商店、合約、交易、釋出） |
| `test-career-market.js` | 37 項 ✔ | 休賽季市場與二軍流程（TEAM／SEED 可換） |
| `test-career-growth.js` | 14／14 ✔ | A4 訓練點→永久能力、傷病 |
| `test-career-pitchlab.js` | 19／19 ✔ | A5 球種成長、投手前輩、退役回顧傷病 |
| `test-career-hub.js` | 60 項 ✔ | 13m 總選單＋13i 休兵日行動 |
| `test-career-hub-integration.js` | 26／26 ✔ | 真 13e＋13h＋13i＋13k＋13m，從總選單走完整季 |
| `test-career-hub-trade.js` | **14／14 ✔** | 賽季中要求交易→換隊（本檔舊寫 12 項，實際 14；`CLEFT=1／2／3` 設剩餘年數） |
| `test-twp-career.js` | 15／15 ✔ | 二刀流（13d＋13e＋13i） |
| `test-twp-create.js` | 9／9 ✔ | 13c 二刀流角色建立 |
| `test-autosim-score.js` | 5／5 ✔ | 13f 自動模擬比分／結算表 |
| `test-catcher-call.js` | 11／11 ✔ | 13j 捕手配球 |
| `test-night-lighting.js` | 13／13 ✔ | 12 的夜間光線數值 |
| `test-ball-roll.js`、`test-ball-wall.js` | PASS ✔ | 04 球的物理統計（滾地彎曲；2000 球不穿牆） |
| `test-webrtc-pairing.js` | PASS ✔（需 `npm install werift`） | 13p 配對：邀請碼 `CP2.o|…`→回覆碼→兩端 DataChannel 都 `open` |
| `test-lockstep.js` | **✘ 路徑錯誤** | 第 3 行讀 `'..','13p-lan-versus.js'`，少了 `js`，會 ENOENT。改成 `'..','js','13p-lan-versus.js'` 後 **PASS**（兩台事件紀錄一致、`P.x` 62.000／62.000、校正 0 次、各 620 步） |
| `test-manual-fielding.js` | **✘ 2／8** | 13g 加了區網對戰（呼叫 `vsOn()`），假環境沒定義 → `ReferenceError`。在假 ctx 補 `vsOn: () => false` 後 **8／8 ✔** |
| `test-update-check.js` | 14 項 ✔（第二十二版改寫） | 13o 自動更新：版本解析、SW 安裝中等待換上→「新版本已就緒」→1.5 秒後重載、版本相同、無新 SW 時自動強制更新（只清 `cpbl2027-` 快取）、手動強制更新、存檔不被清。假計時器現在會觸發 250／800／1200 ms 的 sleep 與輪詢；舊版因假 `setTimeout` 不觸發而靜默退出（假通過）。**一定要在專案根目錄跑** |
| `test-protocol-harness.js` | ✘（TypeError） | 早期除錯用的小工具，寫死 `/home/claude/proj/js/13p-lan-versus.js`，`PTget()` 取到 null；已被 `test-lockstep.js` 取代，不當回歸測試用 |

- **FILE_MAP 提過但本次沒上傳、狀態未驗證**：`test-storage-guard.js`、`test-career-friend-story.js`（7 項）、`test-story-scenes.js`（7 項）、`test-career-condition.js`（9 項）。
- **寫死路徑**：`test-webrtc-pairing.js`、`test-protocol-harness.js` 開頭讀 `/home/claude/proj/js/13p-lan-versus.js`，搬到別的電腦要改路徑。
- 歷史紀錄：早期各版的項數見「第十五版更新」等段，已被上表取代。

## CSS（依載入順序，後者覆蓋前者）
| 檔案 | 內容 |
|---|---|
| `01-base-title-menu-hud.css` | 基礎：標題、選單、HUD、結算 |
| `02-mobile-layout.css` | 手機／平板版面(`body.mob`)、背景音面板、OUT 提示、觸控方向區 |
| `03-menu-lineup-result.css` | v3~v5 選單、賽前編成、結算、主畫面按鈕、開場動畫、離開、投球準度條、ABS 面板 |
| `04-game-buttons-patches.css` | 比賽按鈕主題、ABS 置中、全壘打特效、牛棚、觸控版、能力等級色、「更多」選單、修正補丁 |
| `05-save-system.css` | 存檔／讀取視窗（`#saveDlg`）、主選單「讀取存檔」鈕 |
| `06-transition.css` | **黑幕轉場 `#curtain`**（全螢幕上下百葉窗＋金線＋文字）。`#curtain` 位於 `<body>` 最外層（不在 `#hud` 內），由 `11-game-flow.js` 的 `foulCurtain()` 加／移除 `.on` |
| `07-career.css` | 生涯模式：角色欄位、建立角色、球員卡（`#careerStudio`、`.cr-*`）。接在 06 之後；**已列入 `sw.js` LOCAL（v33 起）** |
| `08-versus.css` | 雙人區網對戰：大廳／配對（`#vsRoot`、`.vs-*`）、投球倒數 `#vsTimer`、連線警告 `#vsWarn`、QR 顯示與掃描（`.vs-qr`、`#vsScan`）、標題「區網對戰」鈕 `.tm-v`。已列入 `sw.js` LOCAL。**注意**：檔內「`body.vs …{display:none!important}`」那條規則目前**不會生效**——13p 實際加在 `<body>` 的是 `vsx`，沒有任何程式加 `vs`（對戰中盜壘／換投／戰術等已改成鎖步事件，不再隱藏）。要隱藏按鈕請改用 `body.vsx`，不需要就可刪掉該規則 |

## 生涯模式（13c＋13d＋13e＋13f，已做到：社會甲組三場 → 選秀 → 落選則上班族一年／選上則進入職業賽季；季後賽已實作（114 年賽制，見該段）；續約與多年度已完成，見後文各版本說明）
**流程**：主畫面「生涯模式」→ `CAREER.open()`（13c 角色欄位）→「▶ 開始生涯」→ `CSEASON.begin(profile, slot)`（13d）→ 賽前介紹 → `launch()` → `newGame()` → 比賽 → `endGame()` → `CSEASON.afterEnd()` 記錄成績 → 下一場／選秀。
- 階段：`SS.year===0` ＝甲組三場（`N_GAMES`）；`SS.year>0` ＝上班族第 N 年（`N_YEAR`＝12 場，每月一場）。每階段結束都會 `doDraft()`；落選就 `startWorkerYear()`，選上則停在「之後劇情待補」。
- 比賽設定（`13d` 的 `launch()`）：`INNINGS`＝9 局、普通難度、ABS 關、特殊事件（evt）關、天氣開。
- 臨時球隊：固定放 `TEAMS[8]`（你的球隊，id `MYS`）、`TEAMS[9]`（對手，id `OPS`），標記 `hidden:true`（`13` 的 `buildCards()` 會略過）；名單在 `CPBL.MYS／CPBL.OPS`，每場由 seed 重新產生（隊名與球員皆虛構）。
- 依位置操控：`G.role = { pos }`＋球員物件的 `isMe` 旗標。`04` 的 `humanBats()/humanPitches()` 與 `06` 的 `humanDef(f)` 會問 `CSEASON.mine()`；`07` 的電腦換投／代打對生涯隊伍也生效（`&& !G.role`），但會排除 `isMe`（電腦不會把你的角色換下場，也不會自己挑你上場；只有 `CPRO.benchCall/bullpenCall` 的安排才會叫你上場）。**之後新增「只有玩家才該能操作」的判斷，請用這幾個函式，不要直接比 `G.human`。**
- **職業賽季（13e）**：選上後 `SS.pro = {team, seed, res[], apps, trust, starter, log[], plan, ...}`。賽程由 `CPRO.genSchedule(seed)` 產生（不存場次，只存 seed 與 `res`＝各場比分）：6 隊輪轉法 5 輪×8 循環＝40 系列（每系列同對手連 3 場，同組對戰每循環主客對調），週五～日每週一次、週二～四隔週一次，週一休兵、7/9 明星賽週停賽；每隊 120 場、對每個對手 24 場（主客各 12），約 3/26～9/30，每月約 17～20 場。其他球隊的比賽由 `simOthers()` 用 `CPBL` 的打擊 OPS／先發防禦率換算實力模擬，我方每打完（或快速模擬）一場就把到當天為止的其他比賽模擬完。
- **板凳候補起步**：打者放 `t.bench`、投手插入牛棚；每場先決定 `plan`（今天有沒有機會用你：機率＝0.2＋信賴度/160，上限 0.8；類型 代打 PH／代跑 PR／登板 RP）。`07` 的 `aiPinch()`／`aiManagePitcher()` 開頭呼叫 `CPRO.benchCall()`／`bullpenCall()`，到達預定局數就用 `subInto()`／`changePitcher()` 叫你上場；`G.roleCall` 存這個安排（已列入 13b 的 `G_KEYS`）。信賴度 ≥70 且出場 ≥10 次升先發（打者進打線；投手每 5 場輪值一次），先發後信賴度 <30 會被調回板凳。
- 職業賽季的比賽設定與社會組相同（9 局、難度可選 弱／普通／強／宗師＝`PR().lv`、**ABS 開（玩家隊每場 3 次）**、特殊事件關），`launch` 在 `CPRO.launch()`；可「快速模擬本場」（含你的登場成績）。
- **自動模擬（13f）**：賽前畫面（13d `showIntro`、13e `showIntro`）選「⏩ 自動模擬」→ `AUTOSIM.arm(true)`，選「👁 全程觀看」→ `arm(false)`。比賽中由 13f 的 rAF 迴圈每幀判斷：`pref && !needMe()` 就快轉。`14` 的 `frame()` 兩處改為 `if (!window.__ff)`（快轉時不繪製 3D、不調畫質）。快轉時的靜音分兩層：①用 `08-audio.js` 自己的靜音旗標，暫時把 `SND.mute`／`BGM.mute` 設 true 並呼叫 `sfxApplyVol()`／`bgmApplyVol()`，結束後還原玩家原本的設定（不寫 localStorage，所以中途關頁面不會把靜音存下來）；②`08` 檔尾的 `AUTOSIM_FF_GUARD` 在 `window.__ff` 為真時讓 `noiseBurst／tone／sweepNoise／ring／shapedNoise／flowSfx／crowdRoar／hornSeq／cheerDrums／hitFanfare／hrFanfare／hitSfx／bounceSfx／applause／crowdGasp／crowdGroan` 直接 return，快轉時不再建立音效節點（高倍速不被音效拖慢）。**之後在 08 新增發聲函式，請把名字加進這份清單。** 背景音樂在 `BGM.mute` 為真時 `bgmTick` 本來就不排程新音符。新增「只有玩家才能操作」的流程時，請確認 `needMe()` 能偵測到（目前看 `humanBats()`、`humanPitches()`、`PL.ask`）。**精準停點**：`14` 的 `frame()` 在 `step()` 迴圈裡，快轉中每走一步就問 `AUTOSIM.needMe()`，為真就立刻 `break`（下一個 rAF 由 13f 的 `tick` 呼叫 `stop()` 恢復畫面與音量）；否則高倍速／卡頓時單一畫面可能推進超過 1 秒，衝過玩家打席的第一球。13f 的 rAF `tick` 註冊早於 14 的 `frame`，所以每幀先 `stop()` 再繪製。
- 選秀分級（`doDraft()`，分數 0～100）：≥70 非常好（80% 喜愛球隊選走，第 1～2 輪）／55～69 還不錯（第 2～3 輪，隨機隊）／40～54 普通（第 4～5 輪，非喜愛隊，20% 落選）／<40 落選。12 場的階段會換算成「三場」標準後評分。
- 生涯進度：`localStorage` 鍵 `cpbl2027.career.season.<角色id>`（賽季＋歷史），角色本身在 `cpbl2027.career.profile.<1~3>`；比賽中存檔由 `SAVE.hooks.career`（13d 覆寫 13c 的版本，多帶 `season`，並提供 `prepare()` 於 13b 驗證前重建臨時球隊）。
- 與引擎的接點：`11` 的 `newGame()`（呼叫 `CSEASON.inject`）與 `endGame()` 末尾（呼叫 `CSEASON.afterEnd`）；13d 也會包裝全域的 `newGame`、`backToTitle`、`makeChibi`（`03` 的 `makeChibi(o)` 是 function 宣告、吃 `o.pl／o.vis`，所以可以包裝，讓 `isMe` 的球員用建立角色時的外觀）。
- 介面：`#csDlg` 與其樣式由 13d 動態插入（不在 css 檔裡）；舊的 `#careerDlg`（「開發中」）已不再使用。

## 手動守備（13g）
- **手機方向盤（已修）**：原本 13g 讀 `PAD.v`，但全部已上傳的檔案中**沒有任何程式設定 `PAD.v`**（`13` 的觸控拖曳只移動畫面上的方向盤圖示並移動瞄準準心），所以手機拖左邊方向鍵一直無效。現在 `13` 的觸控拖曳在 `FM.padNeeded()` 為真時設定 `PAD.f`（拖曳量 ÷40，上＝`vy` 負），13g 的 `inputDir()` 讀 `PAD.f`（`PAD.v` 仍保留相容，目前無人設定）。`14` 的 `frame()` 讀 `PAD.v` 移動準心，所以**不要把方向盤資料放進 `PAD.v`**，會同時拖動準心。
- **快轉中停用（已修）**：`baseOK()` 加 `!window.__ff`。自動模擬快轉時由電腦追球，不再讓被標記 `manual` 的野手站著不動；快轉遇到傳球詢問（`PL.ask`）會自動停下來。
- 生涯模式刻意只能操控「你的角色」（`allowed()`）；球離你超過 16 公尺時**不會**幫你選別的野手，這是設計不是故障。
- 啟用條件：`baseOK()`＝玩家守備、非簡易、`G.assist` 為假、非界外球／全壘打。輔助防守設定：賽前「更多設定」的 pill（`CFG.assist`）、比賽中「☰ 更多」旁邊（`#acts` 列，和止滑粉同一排）的「輔助守備」按鈕（`baseball.html` 的 `#btnAssist`，由 13g 綁定點擊、文字、亮燈（開＝橘色 `.on`），並只在玩家守備且非簡易模式時顯示；原本左上角的小按鈕 `#fmAssist` 已隱藏，13g 的 `SHOW_CHIP` 改 true 可還原）；偏好存 `localStorage: cpbl2027.assistDef`；`11` 的 `newGame()` 把 `CFG.assist` 轉成 `G.assist`。
- 做法：13g 包裝全域 `updatePlay()`，每幀先跑 `FM.pre(dt)`：自動選取、依輸入設定被選野手的 `tx/tz`、搶先撿球（滾地球 1 公尺內、接殺 1.5 公尺內且球高 <2.3 公尺）、差一點點的「手套範圍」拉近（接殺 2.9 公尺／滾地 2.2 公尺）。被操控的野手有 `f.manual=true`：`06` 的 `steerChaser()` 會略過他，`05` 的 `rechaseBall()` 先問 `FM.rechase()`（沒接到就繼續由玩家追）。
- 換人＝把 `PL.plan.f` 與補位表 `PL.cover` 對調；換人後 `locked` 到這一球結束，不再自動選取。
- 球的軌跡、落點與接球／漏接判定仍是引擎預先算好的（`planFielding`），手動只是改成「看你人有沒有在那裡」。
- 外野手手感（比原本快）：`04` 的 `FIELDK_OF` 1.08、`05` 的 `planFielding` 反應 .29／`assignRoles` 起步等待 .1、`06` 的 `steerChaser` 看球時間縮短、落點估計更準、不再放慢腳步等球。要再調快慢，改這幾個數字。
- **玩家操控野手的速度（`13g` 的 `MANUAL_K`，目前 1.2）**：只乘在 `pre()` 裡「被你操控的那一位」的走動速度（含持球跑動），方向盤／方向鍵輕推時最低速為 70%（原 55%）。**刻意不動 `MOVEK`／`FIELDK_OF`／`fspeed()`**：那些同時被電腦野手與 `planFielding`（安打／接殺判定）使用，改了會讓安打變少。想再快或慢，只改 `MANUAL_K`。

## 引擎接點一覽（為生涯／手動守備而改過的既有檔案，改這些地方時要小心別弄壞）
| 檔案 | 位置 | 做什麼 |
|---|---|---|
| `04` | `humanBats/humanPitches` | 加 `(!G.role \|\| CSEASON.mine(...))`；`FIELDK_OF` 1.08 |
| `05` | `planFielding`／`assignRoles`／`rechaseBall` | 外野手反應更快；`rechaseBall` 開頭問 `FM.rechase()` |
| `06` | `humanDef(f)`、`steerChaser`、`askUpdate`、`clearPlay` | 只有自己的角色才問傳球；`f.manual` 略過 AI 追球並調快外野手判斷；走動時暫停傳球倒數；清 `manual` |
| `07` | `aiPinch`／`aiManagePitcher` | 生涯隊伍由電腦調度（排除 `isMe`）；開頭呼叫 `CPRO.benchCall/bullpenCall` |
| `11` | `newGame`／`endGame` | `CSEASON.inject`、`G.assist`；`endGame` 末尾 `CSEASON.afterEnd` |
| `13` | `buildCards`、`padOn`、點擊過濾、`CFG`、`PAD`、觸控拖曳 | 略過 `hidden` 隊；方向盤在手動守備時開啟；`#fmLayer,#fmAssist` 不觸發揮棒；`CFG.assist`；**觸控拖曳（pointerdown／pointermove／endTouch）在手動守備需要方向盤時設定 `PAD.f={vx,vy}`（-1～1），手指直接放在 `#movePad` 上也能拖** |
| `13b` | `loadObj`、`G_KEYS` | `hooks.career.prepare()`；加入 `roleCall` |
| `13c` | 角色欄位按鈕 | 「▶ 開始生涯」→ `CSEASON.begin()` |
| `14` | `frame()` | `if (!window.__ff)` 兩處（快轉不繪製、不調畫質）；`step()` 迴圈內 `if (window.__ff && AUTOSIM.needMe()) break`（輪到你立刻停） |
| `08` | 檔尾 | `AUTOSIM_FF_GUARD`：快轉時發聲函式不建立節點 |
| `baseball.html`／`sw.js` | script 標籤、`LOCAL`、`VERSION` | 13c～13g；「輔助防守」設定選項、`#acts` 列的 `#btnAssist`（「更多」旁）；v14 |

## 已驗證／尚未驗證
- 已對照原始碼確認：`humanBats/humanPitches/humanDef` 是玩家操控的集中判斷點；`subInto(side, old, sub)` 回傳新球員；`makeChibi` 可包裝；`08` 的 `SND.mute／BGM.mute` 可用來靜音；`12` 的電腦教練換人對玩家隊略過；`availPitchers(side)` 回傳 `{p, i}`。
- 只用假資料做過邏輯測試（球隊產生器、選秀分級、賽程產生器、自動模擬畫面、手動守備選取／走位／換人）；**尚未在瀏覽器實機打過整場**，請玩過後回報手感。
- 自動模擬（本次逐行對照 `13f`、`14`、`08`、`sw.js`、`baseball.html`）：script 載入順序（13e→13f→13g→14）與 `sw.js` 的 `LOCAL` 都正確；`08` 所有聲音只經 `SND.master`／`BGM.bus` 兩條總線，靜音旗標能涵蓋全部；`14` 的 `frame()` 兩處 `__ff` 判斷存在；`13f` 的 `start/stop/muteAll` 成對還原 `__ts`、`__ff`、靜音設定。語法檢查（`node --check`）通過。
- **尚未驗證（需要實機或其他檔案）**：①（已處理）13g 與快轉：快轉中手動守備停用、改由電腦代守，見「手動守備」段落；**手機拖曳方向盤與實機手感仍未實機驗證**。②`11-game-flow.js`、`13d`／`13e` 有沒有用 `setTimeout`／真實時間（不是 `step(dt)` 的遊戲時間）做半局轉場，這類延遲不會被快轉加速。③`13d` 是否真的設定 `G.career`（`AUTOSIM.active()` 的條件）。④`say` 的 log 擷取依賴 `say` 是 function 宣告（若是 `const` 會被 try/catch 吞掉，特殊畫面最近播報只會顯示「比賽進行中…」）。
- 第十九版整理時已取得**全部** `js/*.js`、`css/*.css`、`baseball.html`、`sw.js`、`yw_manifest.json`、vendor 兩檔，並逐項對照本檔所列函式／欄位／鍵名（見第十九版）；`tests/` 本次未上傳，測試結果為歷史紀錄，未重跑。
- 已知限制：生涯模式特殊事件關閉（ABS 已開）；鏡頭以球為主、手動守備時會兼顧操控中的野手（見「手動守備鏡頭」）；手動守備沒有主動飛身撲接；職業賽季季後賽、續約與下一年度尚未做。

## 存檔系統（13b）
- 存的是「半局開始」的乾淨狀態；`G.teams` 以圖形序列化（保留共用參照，略過 `def`／THREE／DOM），再配合 `G_KEYS` 列的 `G` 欄位。**新增會跨半局保留的 `G` 欄位，請加進 `13b` 的 `G_KEYS`。**
- **存檔流程（`act('save')`）**：成功就 `close()` 關閉視窗並用 `toast('已儲存（欄位 N）')` 提示一次，不再留在視窗裡；失敗才顯示錯誤訊息並留在視窗。`open()` 有防重入：視窗已開、或剛 `close()` 不到 600 ms 就忽略（`S.closedAt`），避免殘留點擊再次打開。若還有「需要按確認的已儲存訊息」，來源不在 13b（13b 只用 `confirm` 問覆蓋／刪除／中斷比賽），請搜尋其他檔的 `alert(`／`已儲存`。
- 讀檔＝`newGame()` 重建場景與天氣（同球場、日夜）→ 覆蓋球隊與 `G` → 再跑一次 `startHalf()`。
- localStorage 鍵：`cpbl2027.save.<normal|career>.<1~3>`；匯出檔格式 `{app:'cpbl2027', fmt:1, saves:[…]}`，內含 FNV 校驗碼。
- 生涯模式：註冊 `SAVE.hooks.career = { active, collect, apply }` 後，存檔會一併帶上 `collect()` 的資料，讀檔後呼叫 `apply(extra)`。

## PWA／離線（不是遊戲邏輯，但每次新增檔案都要連動）
| 檔案 | 內容 | 修改時機 |
|---|---|---|
| `sw.js` | Service Worker。`LOCAL` ＝離線快取清單、`VERSION` ＝快取版本（目前 **v69**；每次改任何資產就 +1）。本站檔案「先用快取、背景更新」，改版後下次開啟才生效 | **新增／改名／刪除任何 css、js、images 檔**；或想讓所有人立刻換新版（`VERSION` +1） |
| `yw_manifest.json` | PWA 安裝資訊（名稱、圖示、全螢幕、橫向、主題色）。`baseball.html` 以 `<link rel="manifest">` 引用 | 改 App 名稱、圖示、顯示方式 |

> `sw.js` 的 `LOCAL` 目前涵蓋 `baseball.html` 的全部 css／js（含 `13c`～`13p`、`css/01`～`08`）＋ `js/vendor/qrcode.min.js`、`js/vendor/jsqr.min.js`、`images/su.ico`／`su-180／192／512.png`、選用的 `js/three.min.js`（three.js 離線備援，`baseball.html` 在 CDN 載入失敗時才讀它）。新增檔案時務必一併補上，並把 `VERSION` +1。
> `js/vendor/` 兩個檔案不在 `baseball.html`，由 13p 需要時動態載入；`LOCAL` 有列所以可離線使用。

## 任務 → 需要上傳的檔案（給下一個 AI／使用者）
**任何任務都先傳 `FILE_MAP.md`。** 其餘依任務挑選（不確定時多傳 `baseball.html`）。
| 任務 | 請上傳 |
|---|---|
| 轉場／黑幕（半局、就位、換球） | `css/06-transition.css`、`js/11-game-flow.js`、`baseball.html`（若動 DOM） |
| 開場介紹／球場介紹動畫 | `css/02-mobile-layout.css`、`js/11-game-flow.js` |
| 主畫面／標題特效 | `css/03-menu-lineup-result.css`、`js/14-bullpen-loop-boot.js` |
| 賽前選單／編成／戰術面板 | `css/03`、`js/13-ui-input-menu.js` |
| 比賽中按鈕／HUD 版面 | `css/04`、`css/02`（手機）、`js/09-hud-commentary.js` |
| 球員／球隊／能力 | `js/01-core-data.js` |
| 球場外觀、夜間燈光 | `js/02-stadium-scene.js` |
| 球員模型、鏡頭、特效 | `js/03-players-ball-camera.js` |
| 投打手感、物理 | `js/04-pitch-swing-physics.js` |
| 守備／跑壘／判決 | `js/05-…`、`js/06-…` |
| 電腦 AI | `js/07-cpu-ai.js` |
| 音樂音效 | `js/08-audio.js` |
| 實況播報 | `js/09-hud-commentary.js` |
| ABS、驅逐、傷退等事件 | `js/10-events.js` |
| 比賽流程／結算 | `js/11-game-flow.js` |
| 天氣／傷病／心情 | `js/12-systems.js` |
| 存檔／讀檔 | `js/13b-save-system.js`、`css/05-save-system.css` |
| 生涯模式（角色／欄位／球員卡） | `js/13c-career-create.js`、`css/03`（若動樣式） |
| 生涯模式（賽季／選秀／對手／依位置操控） | `js/13d-career-season.js`、`js/04`、`js/06`、`js/11`、`js/13b`（接點） |
| 生涯模式（職業賽季／賽程／板凳出場） | `js/13e-career-pro.js`、`js/13d`、`js/07`（兩個 hook）、`js/10`（`subInto`／`availPitchers`） |
| 自動模擬（快轉／計分板畫面） | `js/13f-career-autosim.js`、`js/14-bullpen-loop-boot.js`（`frame()`）、`js/08-audio.js`（靜音） |
| 手動守備／輔助防守／外野手手感 | `test-manual-fielding.js`（Node 邏輯測試，用假引擎載入 13g）、`js/13g-manual-fielding.js`、`js/05`、`js/06`、`js/04`（數值）、`js/13`（方向盤／設定）、`baseball.html`（設定選項） |
| 生涯劇情事件（職業賽季） | `HANDOVER_CAREER_STORY.md`、`js/13h-career-story.js`、`tests/test-career-story.js`、`js/13e`、`js/13d`、`js/13b`、`js/11` |
| 新增任何檔案 | `baseball.html`、`sw.js`（＋要改的檔） |
| 存檔保護／備份還原 | `js/13n-storage-guard.js`、`js/13b-save-system.js`、`css/05-save-system.css`、`baseball.html` |
| 自動更新／檢查更新 | `js/13o-update-check.js`、`sw.js`、`baseball.html` |
| 雙人區網對戰 | `js/13p-lan-versus.js`、`css/08-versus.css`、`js/04`／`07`／`10`／`11`／`13`／`14`（`vsOn`／`engBats`／`mineBats` 等接點）、`baseball.html`（`#tmVersus`）、`sw.js`（vendor QR 檔） |
| PWA／離線／安裝 | `sw.js`、`yw_manifest.json`、`baseball.html` |
| 不確定原因的樣式問題 | 對應 `css/*.css` 全部（`01` 含最基礎的 `#hud`、`#curtain` 舊規則） |

## 手感數值速查（常被要求調整）
- **甜蜜點擊球強度（`04` 的 `resolveSwing`，`solid` 係數）**：`cz`（球在棒上的位置）算出後定義 `solid`（0～1）＝甜蜜點 × 時機準（`Q` 由 .6 起算、.9 滿）× 球不在棒子上下緣（`|v|`＜.3～.6 漸減）；擦邊（`marginal`）、壞球造成 `Q` 下降、短打時為 0。`solid` 的效果：①初速 ×(1＋solid×.03×…) 並有保底 `25 + solid×(3.5＋1.5×pwk)` m/s（力量普通約 28.5、力量型約 30；在 `ev>30` 壓縮之前；原本 .07／6／5 的版本全壘打太多，已調低）；②初速隨機抖動 −60%、仰角隨機抖動 −35%、上下偏移對仰角的影響 −30%、球種下沉影響 −40%、`luck` −35%；③黃金仰角拉力 ×(1＋solid×.15)（上限 .85；加太多會把球全拉進全壘打仰角）。要調強弱：改保底數字 `25`／`3.5`／`1.5` 與 `.03`；全壘打還是多就先降 `.15`（仰角拉力）；要調「多容易算紮實」：改 `(Q - .6) / .3`。
- 跑動速度：`04-…js` 的 `MOVEK`（跑者＋內野手 .78）、`FIELDK_OF`（外野手 1.08；原 .95，已調快）、`fspeed0()`（個人公式）；跑者速度在 `05-…js` 的 `makeRunnerFromRig`。
- 傳球：`04-…js` 的 `armSpeed()`；彈地／滾地／外野回傳係數在 `05-…js` 的 `throwTo()`。
- 跑壘判決：`06-…js` 的 `CLOSE_T`（close play 視窗）、`safeCheck`／`tagReview`；跑者踩壘時間用 `G.rclk`（由 `updateRunners` 累加，**不要改回 `G.clk`，它沒有人遞增**）。

## 其他
- 搜尋技巧：用 `grep -n "函式名" js/*.js` 找到檔案後，只讀該檔（或用 `sed -n 'a,bp'` 讀區段），不要整包讀。

## 第 3～15 年主線與退役（第七版，13h＋13e）
- **13h**：`PRO_Y3…Y15` 每年一個 `pro_start` 開幕主線（第 8 年依 `econ.mood` 分 `PRO_Y8_COMEBACK`／`PRO_Y8_BODYCARE`）；`PRO_YN_OPENING` 改為第 16 年起；`PRO_RENEW` 只在第 1～14 年。退役事件（`offseason`，第 15 年起）：`PRO_RETIRE_CHAMP`（奪冠才有「最後一舞」）、`PRO_RETIRE`（告別賽／低調／再戰一年）、`PRO_RETIRE_FORCED`（第 20 年起，無「再戰」）。選項把旗標 `RETIRE_CHOICE` 設為 `ceremony／quiet／lastdance／again`。新增事件可用 `Ev(id, phase, title, 條件[], 正文[], [[id,標籤,{t,coach,veteran,team,flag,fv},結果[]]], 額外)` 縮寫。
- **13e**：`seasonSummary()` 多 `st`（本季例行賽累積：ab h hr rbi bb k e outs r hA）；`storyCtx()` 多 `career:{years,titles,playoffs,starterYears}`，並在例行賽／季後賽結束後補 `team.champion`（沒奪冠＝false）；`goNext()` 在劇情後檢查 `RETIRE_CHOICE`，是退役就 `showRetire(kind)`（生涯回顧，設 `P.retired`；之後 `showIntro()` 一律回到回顧畫面）。
- 測試：`test-career-story.js` 44 項、`test-career-integration.js` 83 項（含年 1→年 15 退役；6 隊×3 種子 18 次 0 失敗）、`test-career-economy.js` 12 項。

## 第八版：紀錄／獎項／結局 E／退役故事（13e＋13h）
- **自願退役改為第 10 年起，第 20 年強制**：`PRO_RENEW` 只在第 1～9 年；`PRO_RETIRE_CHAMP`／`PRO_RETIRE`／`PRO_RETIRE_HEALTH`／`PRO_RETIRE_DECLINE`（第 10～19 年，彼此互斥）／`PRO_RETIRE_FORCED`（第 20 年起，無「再戰」）。
- **紀錄（13e）**：每場 `rec.dec`＝勝敗救**簡化推定**（`decide()`；引擎沒有官方決勝投手，規則寫在函式註解與回顧畫面）。`statSum(LG)` 累積 `g w l sv ab h hr rbi bb k e outs r hA`（`r`＝投手自責分，防禦率＝r×27÷outs）。`seasonSummary()` 每年存 `st`（例行賽）、`pst`（季後賽）、`aw`（榮譽），進 `P.hist`；全在 `SS.pro`，所以隨賽季存檔與比賽中存檔（`collect()` 整包 `SS`）一起儲存。
- **榮譽（`awardsFor`）**：球團表彰，只用個人成績門檻判定（聯盟沒有其他球員的個人數據，不是聯盟投票）。不保證每年都有。
- **結局 E**：`careerCtx` 新增 `heavy`（高出賽／高投球量球季數，打者 ab≥400、投手 outs≥450）與 `lowYears`（信賴度<35 且非先發的球季數）。`heavy≥7`→`PRO_RETIRE_HEALTH`（health）；`lowYears≥2`→`PRO_RETIRE_DECLINE`（decline）；兩者都保留「再戰一年」。`RETIRE_CHOICE` 值：ceremony／quiet／lastdance／health／decline／again。
- **退役流程**：`goNext()`→`showRetire(kind)`（逐年成績表、季後賽累積、榮譽、全程文字故事 `buildStory`）→按「✅ 確認，告別球場」→`showCivilian()`（回歸平凡、幸福平淡的日子；可回看回顧）。`P.retired`／`P.civil` 存檔；之後 `showIntro()` 直接回到對應畫面。
- 測試：story 45／economy 12／integration 82（RETIRE_AT=10／14／20×6 隊×3 種子共 54 次 0 失敗）。環境變數 `RETIRE_AT=<年>` 控制測試在第幾年選退役。

## 合約／市場／二軍（A2＋A3；13i 純邏輯＋13e 介面）
- **13i（`CECON`）新增**：`ensureContract`（舊存檔補 2 年約）、`offerFor／ownOffer／faOffers／tradeTry／evalFate／moveEffect／applyPending`；`settle()` 有合約時領**合約年薪**（二軍 6 折）並把剩餘年數 −1，沒有合約仍用舊算法。欄位：`P.contract{team,years,left,salary,since}`、`P.pending`（選好、下一年才生效的簽約／轉隊）、`P.moves[]`、`P.market`（本休賽季市場畫面狀態）。
- **13e 休賽季流程**：續約談話事件（13h `PRO_RENEW`，只改文案，仍每年一次）→ `settleYear()`（領薪、合約 −1）→ **`showMarket()`**（stage：`stay` 合約未到期／`expiry` 到期／`fa` 自由市場／`tradePick` 要求交易成功／`traded` 球團主動交易／`done`）→ 商店 → `nextYear()`（先存本季摘要＝舊球隊，再 `applyPending()` 換隊）。市場內容存 `P.market`，重進不重算、不重複領薪。
- **規則（皆為起始值，可調）**：本隊續約需表現分數 ≥18；自由市場 3 個報價（薪水 ×0.9～1.15）；先發報價只在「本季是先發且分數 ≥55，或分數 ≥70」才有；換隊信賴度 ×0.85、層級回一軍；表現差（信賴度 <15／<25／<35 且非先發，第 1 年減半、二軍 +0.1）可能被交易或釋出，釋出限「合約到期或信賴度 <20」，被釋出只有 1～2 個低薪 1 年板凳約；要求交易成功率 30～90%，失敗心情 −8、每年一次。
- **A3 二軍（13e `farmStep／FARM`）**：一軍板凳信賴度 <15 連續 6 場 → `P.level='farm'`（信賴度改 28）；二軍：`plan()` 一律不出賽、賽前畫面只有「直接出結果／快轉 10 場」、每 5 場依 `trainMult` 加信賴度、≥45 且滿 10 場有 60% 召回（回板凳）；新球季若信賴度 ≥40 自動召回。
- 測試：`tests/test-career-economy.js`（純邏輯 20 項）、`tests/test-career-market.js`（市場與二軍流程 37 項，假環境）、`test-career-story.js`／`test-career-integration.js`（回歸；integration 加 `mkt()` 處理新的市場畫面）。

## 生涯模式守備／捕手配球（第十版）
- **13g（修正）**：生涯模式（`G.role`）不再自動把追球權搶給你的角色。新增 `takeChase(g)`；你的野手平常維持電腦原本的補位／後援跑位（`manual=false`），按方向鍵才接手（`f._fmTook`）；你的野手「先碰到球」（接殺：高度<2.3m 且距離<1.5m 且電腦還沒接到／滾地：高度<1m 且距離<1m／漏接球 `PL.looseF`）才算你的，可以和電腦隊友搶球；`rechase` 在你不是追球者時回 false（交還電腦）。一般比賽（非生涯）行為不變。
- **13j（新檔 `CCALL`）**：你是捕手（`E.F.C.pl.isMe`）且你的球隊守備時，電腦投手準備投球前先開配球面板：球種＋5×5 落點、外角球（pitchout）、牽制 1／2／3 壘、電腦決定、本場全交給電腦。只包裝 `cpuDeliver／aiPickPitch／aiPickoffThink／doPitch／doPickoff`，不改 04／07／11。載入位置：13g 之後、14 之前（baseball.html、sw.js 已加）。
- **13f**：`needMe()` 多一個條件 `CCALL.need()`（配球面板開著時暫停快轉）。
- 測試：`tests/test-manual-fielding.js`（8 項）、`tests/test-catcher-call.js`（11 項），皆假環境。

## 自動模擬面板比分（第十一版）
- **13f**：快轉面板上方新增大比分（`scoreHead`）：客隊／主隊分數、你的球隊標「（你）」、局數與出局數。測試：`tests/test-autosim-score.js`（假環境 1 項）。
- **尚未做**：①快轉加速（要改 `14-bullpen-loop-boot.js` 的主迴圈，加「快轉時每幀多跑幾步邏輯、不繪製」）；②夜間場景配色（`02-stadium-scene.js` 等）。兩者都等使用者上傳 14／02／03／12。

## 快轉預算迴圈／打席結算表／夜間光線（第十二版）
- **14（`frame()`）**：新增分支——`window.__ff && window.__ffBudget > 0` 時，每幀在時間預算（毫秒）內連續呼叫 `step(1/60)` 直到預算用完或 `AUTOSIM.needMe()`，不繪製；沒有 `__ffBudget` 時走原本的 `__ts` 迴圈。
- **13f**：快轉速度改為「快／更快／極速」＝預算 20／40／80 ms（拿掉依 FRAME_AVG 自動降速）；包裝 `finishAB`（11），用打者 `st` 前後差值產生每個打席的結算（局、打者、結果、比分），快轉面板顯示結算表（可捲動）；輪到你時暫停（`G.ts=0`）並顯示「剛才的比賽結果」，按「繼續」還原。按「恢復觀看」造成的停止不顯示回顧。
- **12（`SKYN`）**：夜間光線改為接近白天、偏暖、略暗（黃昏感）：hemi／sun／泛光強度與顏色；天空與霧維持近黑，星空沿用 02 的 `updateNight`（天晴才有）。
- 測試：`test-autosim-score.js`（5 項）、`test-night-lighting.js`（數值檢查 13 項）。

## 二刀流（第十三版：程式已改、假環境測過、**尚未實機驗證**）
- **資料模型**：`profile.pos='TWP'`、`profile.two=true`（13c `sanitize` 維護；其他位置會刪掉 `two`，舊角色資料不變）。比賽中同一角色有**兩個 `isMe` 物件**：投手（`t.pitchers`）＋打者（DH 棒次或板凳）。`G.role={pos:'TWP',two:true}`；`CAREER.session.player`＝投手物件、`playerBat`＝打者物件。`CSEASON.twp=true` 讓 13c 編輯器顯示「二刀流」。
- **能力**：投手一套 `CSEASON.core.myRowPit(p)`、打者一套 `myRow(p)`（TWP 時回傳 DH 打者），兩套數值與單一位置完全相同、不打折。13c 沒有能力點數系統，所以不需分配。
- **13d**：`inject()` TWP 分支（投手進先發、打者取代 DH 棒次、原 DH 進板凳、`t.dh=true`）；`findMe()` 仍回第一個 isMe（打者優先），另有 `findMeBat()`／`findMePit()`；`buildRec()` TWP：**頂層＝打擊成績、`rec.pit`＝投球成績**；`recLine` 同時顯示；`scoreOf` TWP＝打擊面÷2＋投球面÷2＋6；選秀畫面球員卡顯示兩邊。
- **13e**：`plan()` 多 `sp`（今天先發投球）。先發二刀流：每場打 DH，輪值日（`spTurn%5===0`）再先發投球；非輪值日不放投手物件。板凳二刀流：每天只放一個身分（`type:'RP'`→牛棚投手；`PH/PR`→板凳打者）。`injectTwp()`、`benchCall`（RP 日不叫打者）、`bullpenCall`（只在 RP 日叫投手）、`statSum`（頂層＝打擊、`o.pit`＝投球，勝敗救在 `o.pit`）、`decide`（只看 `rec.pit`）、`awardsFor`（投打任一邊達標；另有「🌟 二刀流雙料」15 轟＋8 勝）、`growth`（信賴度＝打擊分＋投球分）、`quick`、`afterEnd`、`statLine`、`recTable`（打擊表＋投球表）、`buildStory`、`careerCtx.heavy`（打數≥400 或投球出局≥450）。
- **13f**：`roleLine()` 二刀流顯示「先發 DH＋是否輪值投球」。`needMe()` 不用改（兩個身分都由 `humanBats/humanPitches` 偵測）。
- **13i**：`afterGame` 多 `o.two={pit}`：投＋打 −9、只打 −4（單一位置：投手 −6、野手 −3）；`P.two` 時 `settle` 休賽季只恢復到上限 −8。`SS.pro.two` 由 13e `start()` 設定。
- **不用改（讀碼確認只看 isMe）**：04 `humanBats/humanPitches`、07 AI 換人（排除 isMe）、11、13g（`allowed`＝isMe）、13j。
- **舊存檔**：`SS.pro` 沒有 `two`／`plan.sp`／`st.pit` 時全部走原路徑；已用 `test-career-market.js`（37 項）在原版與修改版對照。
- **已知限制／未驗證**：①`buildTeam／mkBatter／mkPitcher／subInto／changePitcher／availPitchers` 不在已上傳檔案，只用假版測試；②`t.dh` 在已上傳檔案中沒有任何地方設定（11 的 `changePitcher` 在 `!t.dh` 時會把 `lineup[8]` 換成投手打擊），二刀流的 inject 自己設 `t.dh=true` 作防護，但一般生涯（P／野手）在換投後 DH 是否被換掉，要看 `buildTeam`；③電腦可能把你的先發投手換下（與原本投手角色相同），打者物件會留在 DH 棒次；④二刀流疲勞在「只登板（RP 日）」時以「投球」計 −9（不知道當天有沒有打）；⑤13h 劇情事件沒有二刀流專屬條件。
- 測試：`tests/test-twp-create.js`（9 項）、`tests/test-twp-career.js`（15 項），皆假環境；`test-career-economy.js` 20／20、`test-autosim-score.js` 5／5、`test-manual-fielding.js` 8／8、`test-career-market.js` 37／37（缺 13h 時以空替身）。**未能執行**：`test-career-story.js`、`test-career-integration.js`（缺 13h）、`test-catcher-call.js`（缺 13j）、`test-night-lighting.js`（缺 12）。

## 角色外觀新欄位（v27）
13c 角色 profile 新增：hatMode（std／cap／bare，比賽帽子設定）、eyeType、brow、nose、mouth、blush、glasses、headband、necklace、wristband、accCol、sw（肩寬）、gut（肚子）；`sanitize()` 會替舊存檔補預設值。`toVis(p, bare)` 輸出同名欄位，03 的 `makeChibi` 依 `vis.hatMode` 決定是否戴頭盔／球帽，並由 `addHairEars`、`addFace`、`addExtras` 繪製新髮型、五官與配件。

## 手動守備鏡頭（v28）
- `03` 的 `camChase`：玩家手動守備（`FM.selected` 且 `FM.padNeeded()`）時，球在場內且未被持住（`PL.state` 為 flight／loose）→ 離本壘 >26 m 就推近外野特寫，**球停在牆邊也不拉遠**（原規則「球速 <2.5 持續 0.35 秒就拉回遠景」只在非手動時使用）；球被撿起（held）或傳出（thrown）→ 慢慢拉回遠景。球與操控野手相距 >6 m 時，看的位置往野手偏、鏡頭後退並稍微加寬 fov（50～56）。
- 依賴：`FM`（13g）、`PL`（05）皆以 `typeof` 與 try/catch 保護，缺少時退回原行為。`focus` 是否為球位置來自呼叫 `updateCamera` 的檔案（未確認）。
- **未實機驗證**；改了 03，`sw.js` 的 `VERSION` 需 +1。

## ABS 跑壘挑戰：多鏡頭慢動作回放（13l）
- **`js/13l-abs-camreplay.js`（`ABSCAM`）**：取代 06 `showRaceReplay` 的「時間軸圖表」。平常（有跑者在跑／在壘上、ABS 開、未凍結、非快轉）每幀錄跑者＋9 位野手的 3D 姿勢與球位置（環狀緩衝約 2.5 秒）；包住 06 的 `tagReview()`（close play 發生、尚未判決時複製最近 1.7 秒）、`showRaceReplay()`、`rpHide()`。挑戰成立後從 3 個機位慢動作重播（壘包正面／俯視／壘包側面），在「球入手套」「跑者踩壘」兩瞬間定格並標示時間差，最後顯示 SAFE／OUT、毫秒差與主審原判是否誤判；可按「跳過」或 Space／Enter／Esc。
- **全壘打／界外／場地規則二壘安打**（06 `showFieldReplay`）同樣改成 3 機位慢動作：直接用 `sim.S`（球的模擬軌跡）重播，不需錄影。全壘打柱判定（`rv.mode==='pole'`）：沿界線／界線側面（半透明界線平面，界內在前、界外在後）／俯視；越牆瞬間判定（`'bounce'`）：牆邊側面（牆頂線）／本壘方向／俯視。畫面有軌跡點、越牆點與落地點標記，定格標示時間差，最後顯示判決與是否誤判。
- 不改判決邏輯（06 仍決定結果）。跑壘錄影不足、找不到壘包座標（`baseSpot`）、或自動模擬快轉（`__ff`）時，退回原本的圖表。
- 回放時鏡頭模式暫設 `CAMC.mode='rcam'`（03 的 `updateCamera` 只會往 `tpos/tlook/tfov` 內插），結束後還原；回放中 `body.rpcam` 會隱藏 `#leftCol／#acts／#absPanel`。
- 載入位置：13k 之後、14 之前（`baseball.html`、`sw.js` v30 已加）。測試：假環境（jsdom＋three r128）驗證錄影→回放→還原→回退路徑；**3D 畫面與鏡頭構圖尚未實機驗證**。

## 生涯總選單 HUB（13m＋13i；第十版，取代第九版描述）
- **流程改變**：`13e` 的 `showIntro()` 現在是「生涯主入口」：退役／賽季結束／劇情事件照舊先處理，之後若有載入 13m（`CHUB`）就顯示**總選單**（`hubOpen()`），否則維持舊畫面。原本的賽前畫面改名 `showGameDay(g)`（全程觀看／自動模擬／直接出結果／二軍快轉），只有在總選單賽程月曆「點下一場比賽日 → ▶ 進入比賽畫面」才會進入；該畫面有「☰ 返回總選單」。比賽結束、快速模擬後都回到總選單。
- **總選單分頁（13m）**：總覽（球隊勝敗和、名次）／🗓 賽程（月曆；金框＝下一場，只有下一場能進；藍虛線＝可安排的休兵日；✔＝已安排）／🏋 訓練休息（列出下一場前的休兵日）／🤝 交友／🔁 交易合約（要求交易、選去處）／🛍 消費（買吃飯、約會、設備）／📈 戰績（成績、聯盟勝敗表、歷年、榮譽）。13m 只負責畫面；資料與動作由 13e 的 `hubApi()` 傳入，邏輯在 13i。
- **休兵日行動（13i：`ensureHub／hubActs／hubDo`）**：休兵日＝「上一場已打完的日期之後、下一場之前」且我方沒比賽的日子；同一天只能一個、選了不能改。行動：專項訓練（體能 −8、信賴度 +1，本季上限 6）、休息（體能 +12、心情 +2）、約會（沿用商店：10 萬、心情 +14、每季 3 次）、找總教練／前輩／同梯好友（好感 +6、心情＋）。好感達 50 一次性回饋：教練 信賴度 +3、前輩 訓練上限 6→9、好友 心情 +10。所有數字都是起始值，花費只有時間與體能，不改寫比賽結果。
- **存檔欄位 `SS.pro.hub`**：`{ year, days:{日期鍵yyyymmdd:行動}, trainGain, tradeAsked, tradeOffers, fr:{coach,veteran,mate:{aff,got}} }`；`days／trainGain／tradeAsked／tradeOffers` 每個新年度重置，`fr` 跨年保留；舊存檔缺欄位由 `ensureHub()` 補預設。隨 13d `saveSeason()` 整包存。
- **賽季中交易**：要求交易（每年一次，成功率依表現）成功後在 `P.pending` 寫入去處（下一年生效）；`13e` 的 `showMarket()` 若發現已有 `P.pending` 就跳過休賽季市場。
- 橫幅圖：13k 的 `BY_ID` 新增 `HUB_OVERVIEW／HUB_SCHEDULE／HUB_TRAIN／HUB_FRIEND／HUB_CONTRACT／HUB_SHOP／HUB_RECORD`（重用既有場景）。
- 13j、13l 的說明見「生涯模式守備／捕手配球（第十版）」與「ABS 跑壘挑戰：多鏡頭慢動作回放（13l）」兩段。
- 測試：`node tests/test-career-hub.js`（真 13i＋13m＋假 DOM＋假 api，60 項）。**未在瀏覽器實機驗證；未用真 13e 跑整合測試。** `sw.js` VERSION v32。

## 第十四版更新（HUB 修正＋交友劇情＋專屬插畫＋體能設備影響能力；`sw.js` VERSION v33）
- **sw.js**：`LOCAL` 補上 `css/07-career.css`（`baseball.html` 本來就載入，但離線快取漏列）；VERSION v32 → v33。現在 `baseball.html` 的 css／js 與 `LOCAL` 完全一致（有測過）。
- **13m 修正**：月曆月份（`S.month`）原本設定後不會跟著「下一場」換月，打完 3 月最後一場後仍停在 3 月、看不到金框。`open()` 現在每次從外部進入總選單都重設月份與選取日（畫面內重繪走 `render`，不受影響）。
- **交友劇情（13h＋13e）**：13h 新增 6 個 `after_game` 事件（一生一次、優先 18）：`FRIEND_COACH_30／70`、`FRIEND_VET_30／70`、`FRIEND_MATE_30／70`（好感 ≥30、≥70；人物皆為虛構）。條件欄位 `friend.coach／veteran／mate`（0～100）由 13e `storyCtx0()` 的 `friendCtx(P)` 從 `P.hub.fr` 提供；**沒有 `P.hub` 就不提供 → 事件不出現**。好感在總選單休兵日「找人聊聊」時增加，達標後打完下一場出現事件。選項效果：信賴度、關係值、旗標（`COACH_BOND／VET_BOND／MATE_BOND`），並新增 adapter 目標 `mood`（13e `storyAdapter()`，只在有 13i 時提供；沒有則由引擎略過）。同時達標時 30 級先出、70 級接著出。**13i 沒有改。**
- **專屬插畫（13k）**：新增 6 個場景並接到交友事件（教練室／場邊談心／儲物櫃／前輩叮嚀沿用休息區／深夜宵夜攤／看台夕陽），總選單賽程分頁橫幅改用 `calendar`。**只驗證結構（標籤成對、id 不撞、對應正確），沒有實際看過畫面（環境沒有 SVG 渲染器），請實機檢視版面與配色。**
- **體能／心情／設備影響能力（13i＋13e＋13m）**：引擎本來就有 `mood`（`moodBonus`：50 為基準、**±4.5% 能力**；心情 <55 投手掉體力較快），但 13d／13e 把角色的 `mood` 寫死為 62。現在 13i 新增 `CECON.gameMood(P)`＝`clamp(62 + (心情−60)×0.45 + (體能−80)×0.3 + 設備×0.8, 30, 85)`，13e 的 `inject`／`injectTwp` 用 `gameMood()` 取代 62（沒有 13i 仍是 62）。預設值（心情 60、體能 80、設備 0）剛好是 62，所以沒操作的玩家不受影響；上限對應約 +3.2%、下限約 −1.8% 能力。**只改 mood，不碰先發身分、信賴度、比賽結果，不能買先發。** 總選單總覽頁新增「開賽狀態」一列顯示數值與約略能力％。13d（社會組）沒改，因為那個階段沒有經濟欄位。數值全是起始值。
- **新增測試**：`tests/test-career-hub-integration.js`（真 13e＋13i＋13k＋13m，從總選單走完整季，26 項；6 隊×3 種子皆過）、`tests/test-career-friend-story.js`（7 項）、`tests/test-story-scenes.js`（7 項）、`tests/test-career-condition.js`（9 項）。`test-career-story.js` 事件數改為 46。
- **舊整合測試**：`tests/test-career-integration.js` 不載入 13k／13m，所以走舊賽前畫面（`typeof CHUB === 'undefined'`），仍可用；新的總選單流程由 `test-career-hub-integration.js` 負責。該測試的通過項數會因隨機結果在 63／83 之間變動（晉級與否的分支不同），都是全過。
- **仍無法執行的測試（缺檔，不是失敗）**：`test-autosim-score`（缺 13f）、`test-catcher-call`（缺 13j）、`test-manual-fielding`（缺 13g）、`test-night-lighting`（缺 12-systems）、`test-twp-create`（缺 13c）。

## 第十五版更新（合約年數修正＋測試整理；`sw.js` VERSION v34）
- **修正（13m 選去處）**：賽季中從總選單要求交易、選「沿用合約（keep）」的去處時，`P.pending.years` 原本直接用當時的剩餘年數；但本季結算（`settle`）還會再把剩餘年數 −1，所以換隊生效後新合約會多一年（休賽季市場是結算後才選，沒有這個問題）。現在 13m 的 `data-pick` 對 `keep` 的報價改用 `Math.max(1, o.years - 1)`（至少 1 年，不會出現 0 年約）。非 keep 的報價（合約已到期、重簽新約）不變。只改 13m 一行；13e／13i 沒動。
- **`sw.js`**：VERSION v33 → v34（13m 內容改了，讓已安裝的玩家拿到新版）。沒有新增 css／js／images，所以 `baseball.html` 與 `LOCAL` 不用改。
- **測試**：`test-career-story.js` 事件數 40 → 46（原本的檔案是舊版，與程式不符）；新增 `tests/test-career-hub-trade.js`（真 13e＋13h＋13i＋13k＋13m：賽季中要求交易→選去處→整季→休賽季跳過市場→nextYear 換隊；環境變數 `CLEFT=1／2／3` 設定交易前合約剩餘年數、`TEAM`／`SEED`；12 項）。
- **最新測試結果（Node v22，假環境；沒有真引擎、沒有瀏覽器）**：test-career-hub 60、test-career-hub-integration 26、test-career-hub-trade 12、test-career-integration 63／83、test-career-market 37、test-career-economy 20、test-career-story 45、test-twp-career 15、test-twp-create 9、test-autosim-score 5、test-catcher-call 11、test-manual-fielding 8、test-night-lighting 13，全部 0 失敗；hub-integration／integration／market／hub-trade 各以 6 隊×3 種子（123／222／777）共 18 次皆通過。
- **未取得／未執行的測試**：`test-career-friend-story`、`test-story-scenes`、`test-career-condition`（交接檔提到、尚未上傳）。
- 「生涯模式（13c＋13d＋13e＋13f…）」段標題原寫「續約與下一年度尚未做」，已於第十九版更正。



## 第十六版更新（A4：訓練改成永久能力成長＋傷病；2026-10-22）
- `js/13i-career-economy.js`：新增 `ensureGrow／growthSettle／abilTx／applyAbil／injured／injuryRisk／injuryRoll／injuryTick／rehab／injuryYearEnd`；`hubActs／hubDo` 的專項訓練**不再加信賴度**，改累積訓練點（`P.grow.tp`），出現受傷時多一個「🩹 復健」行動；`fitCap` 加上永久體能成長（`P.abil.body`，≤ +10）；`evalFate` 受傷中一律不處置。新存檔欄位：`P.grow {tp, rem}`、`P.abil {con,pow,eye,spd,fld,arm,vel,stf,ctl,sta,dur,body}`、`P.injury`、`P.injLog`（舊存檔由 `ensureGrow` 補預設）。
- `js/13e-career-pro.js`：`ab()` 在每個 `mkBatter／mkPitcher` 之後、`setPos` 之前套用永久能力（7 處，含二刀流）；`settleYear` 在 `E.settle` 之後呼叫 `growthSettle`（**必須在 hub 年度重置之前**，訓練點因此存在 `P.grow` 而不是 `P.hub`）；`growth()` 每場先 `injuryTick`、出賽後 `injuryRoll`；`plan／showGameDay／showPO` 以 `sitOut()`（二軍或受傷）判斷不出賽（和二軍同一條快轉路徑）；`farmStep` 二軍每 5 場 +1.5 訓練點、受傷不累積下放計數；`nextYear` 呼叫 `injuryYearEnd`；`showShop` 休賽季顯示本季成長；`CPRO._t` 多匯出 `plan／growth`（測試用）。
- `js/13m-career-hub.js`：總覽顯示傷勢；訓練頁顯示訓練點、永久能力成長、傷病說明；`ACT_TX` 加 `rehab`。
- `sw.js`：VERSION v34 → v35（沒有新增檔案）。
- 測試：新增 `tests/test-career-growth.js`（14 項）；改 `test-career-hub.js`（訓練不再 +1 信賴度）、`test-career-hub-trade.js`（加訓練點→休賽季結算檢查）、`test-career-integration.js`（受傷時畫面只有「快轉 10 場」，與二軍相同）、`test-career-market.js`（釋出情境先清除傷勢）。
- 所有數字都是起始值：訓練 +3 點×倍率、`TP_DIV=4`、每項每季 ≤ +3、終身 ≤ +15、體能 ≤ +10、第 9／13 年起成長 ×0.7／×0.4、受傷機率每場 0.5%（輕 75%／中 22%／重 3%）。

## 第十七版（A5）：球種成長／請教投手前輩學新球種／訓練方向／退役回顧傷病（13i＋13e＋13m）
- **13i（`CECON`）**：`P.pitchLab {up, xp, learned, mentors, base}`（`ensurePitchLab`）；`P.grow.focus`＝訓練方向（能力名或 `pitch:球種id`，長期保留、可隨時改）。球種等級 1～7：原有球種上限＝原始等級 +3（≤7）、新學球種從 Lv1 起最高 Lv6、最多 6 種球種（`MAX_PITCHES`）、每季每球種最多 +1 級（升級經驗 `PITCH_NEED`）。`growthSettle(P,S,pos,opts)` 的 `opts={pitches,rnd}`：回傳多 `pitchGains`／`focus`／`focusBonus`；指定能力方向＝該能力權重 ×1.8、其餘 ×0.85，另有 15～50% 額外 +1（仍受上限）；指定球種方向＝球種經驗 75% 給它。`applyAbil` 末尾呼叫 `applyPitches`：把等級成長與新球種套到引擎投手的 `pitches[]`（傳說球員 `ultra` 略過）並記錄 `pitchLab.base`。休兵日行動新增 `pmeet`（結識虛構投手前輩）、`pask:<前輩id>`（請教；好感 +8，達門檻後有 25～60% 學會）。10 位前輩見 `MENTORS`（虛構）。`injurySummary(P)` 供退役回顧。
- **13e**：`basePitches()`（用 `mkPitcher` 取原始球種）；`settleYear` 傳 `{pitches}`；`hubApi` 先 `notePitches`；休賽季結算畫面顯示球種升級；`injHtml()`＋`buildStory` 加傷病紀錄表與故事段落（取自 `P.injLog`）。
- **13m**：訓練分頁加「🎯 訓練方向」按鈕列與「⚾ 球種等級」；交友分頁加「投手前輩」；`actTx()` 顯示休兵日行動名稱。
- 測試：`node tests/test-career-pitchlab.js`（19 項，含 13m 假 DOM、假環境載入真 13e 的退役回顧）。**未在瀏覽器實機驗證；需要 13d／13h 的測試（growth 3 項、twp-career、integration 類）在缺檔的環境跑不了，請在完整專案重跑。**

## 第十八版：生涯模式與畫面大修（sw.js v52 → v57；沒有新增 css／js 以外的資產，13n 為新檔）
- **球與守備**：`04` `rollG` 滾地彎曲／首彈偏移、擊球方向散布、擊球框 `BAT_FRAME_R`／`batFrameR`／`fitR`（依裝置縮放）；`05`／`06` 外野手反應收斂、`smartInterceptor`、界外球追球（`oob = sim.over || dist>60`）、`rechaseBall` 夾住牆邊；`11` 回位速度提高。
- **跑壘**：`06` `retreatCands`／`doRetreat`／`forcedBehind` 讓任何壘上跑者都能隨時推進／回壘；**牽制（`11` `doPickoff`）**：回壘動作（離壘>1.7m 才撲壘、回壘速度 7）、警戒值 `r.wary` 影響離壘（`05` 離壘×(1−警戒×.35)）、牽制體力 `pkLoad` +2.4＋1.1×次數、盜壘時投手快速投球（×.85）與捕手出手延遲×.6。
- **ABS**：`06` `absJudge`（跑壘／全壘打）與 `10` `absFlow`（好壞球）：生涯模式玩家沒上場時（`G.career && G.role && !(humanBats()||humanPitches())`）改由電腦教練決定；電腦教練會看局數／分差／得點圈挑時機；`13e` 開局雙方各 3 次、`absStat` 保證存在。
- **結算畫面**：`11` 檔尾用 MutationObserver 在 `#result` 顯示時替 body 加 `resOn`，`css/04` 以 `body.resOn` 隱藏 HUD（取代 `:has`，舊瀏覽器也有效）；資訊面板（`.pbox`／`#windBox`／`#warmBox`／`#sb`／`#bso`）背景再透明；電腦版 `#pinfo` 預設摺起（`dopen` 切換）。
- **球種選單 `#pitchPanel`**：投球圓鈕 `#touchBtns` 只在觸控／手機顯示（`css/01` 預設 `display:none`）；`css/04` 檔尾規則把選單貼在圓鈕左側（`body.touch`／`body.mob`），電腦版維持右下原位。
- **生涯主畫面與難度**：`13m` `pageHome`（主畫面分頁）、`13e` `lvOf()`／難度選單；`13f` 自動模擬背景 `AS_BG`、略過開場、速度 `SPEEDS=[40,80,160]`。
- **存檔**：`13b`（檔案系統備份／還原、`svFileTog`、`svSync`）＋`13n-storage-guard.js`（`STORE_GUARD`、`#sgFab`、`#sgDlg`；`sw.js` LOCAL 已含）。
- **球場畫面 `02`**：草葉細紋、壘間紅土跑道與顆粒、外野警戒區 `track`、牆底護墊 `wallPad`、界外柱 `POLES`／`placePoles()`、看台階梯橫紋；`applyPark` 會重建這些並**修正 `WALL_H = k.h` 被註解吃掉的舊 bug**（各球場牆高 5.0～5.8m 現在才生效）。**尚未實際渲染驗證**（環境無法取得 three.js）。
- **測試**：新增 `test-ball-roll.js`、`test-ball-wall.js`、`test-storage-guard.js`；可執行且通過：`test-autosim-score`(5)、`test-career-hub`(60)、`test-career-economy`(20)、`test-career-pitchlab`(19)、`test-ball-roll`／`test-ball-wall`／`test-storage-guard`。需要 13d／13g／13h／13j 的測試仍無法執行。
- **v58 自動更新**：新增 `js/13o-update-check.js`（已加入 `baseball.html` 與 `sw.js` LOCAL）；`sw.js` 新增 `message` 回報 VERSION、`sw.js` 本身一律走網路（`no-store`）、其他本站檔案背景更新改用 `cache:'no-cache'`（不吃瀏覽器 HTTP 快取）；`baseball.html` 註冊改 `updateViaCache:'none'`。

## 雙人區網對戰（js/13p-lan-versus.js ＋ css/08-versus.css）
- 同一 Wi-Fi、兩支手機各選一隊。WebRTC DataChannel 直連，靠「邀請碼／回覆碼」手動交換（不需伺服器）。
- 原理：兩台各跑一份相同模擬（14 的 frame 在 `vsOn()` 時改固定 1/60 步長；`step`／各種裝飾性函式在對戰期間被 13p 包住，亂數統一用同種子）。只互傳：投球選擇(pitch/lock)、打者判定(swing，以打者那台為準)、不揮棒(take)、球軌跡快照(ptsnap)、短打切換(bunt)、準備好(ready)。
- 引擎層 vs 介面層：04 新增 `vsOn/engBats/engPitches`（引擎：連線時兩邊都算真人）與 `mineBats/minePitches/MYH`（介面：這支手機操控哪一隊）。13 的介面判斷已全部改用 mine*／MYH()。`G.human` 在兩台都是「房主那一隊」，不可再用它判斷「我是誰」。
- 投球倒數：壘上無人 15 秒、有人 18 秒（13p 的 TIME_NO／TIME_RUN），超時自動投直球。
- 對戰中停用（兩邊由電腦代理或先隱藏）：盜壘／牽制／止滑粉／換投／戰術／推進回壘／手動守備／ABS／天氣／意外事件。CSS 用 `body.vs` 隱藏按鈕。
- 改了 04/07/11/14 的任何「真人 vs 電腦」分支時，要想一下對戰模式：引擎層用 engBats/engPitches，吃本機輸入的用 mineBats/minePitches。


## 區網對戰 第三版（v63）：全程鎖步＋房主權威校正＋ABS
- **傳輸**：仍是 WebRTC DataChannel（P2P 直連、即時雙向、不需伺服器）。房主＝權威（A 掃 B 的 QR 配對後由房主開賽）。沒有加 WebSocket：它需要一台中繼伺服器，專案是純靜態網頁。
- **共同時鐘**：`VS.ep`（每球一個 epoch，`VS.onPre` 遞增）＋`VS.ck`（epoch 內的步數）。`step` 包裝層每步互報 `sn`，領先對方超過 `LEAD=4` 步就暫停等（逾時 1.5 秒放行並記錄）。等對手投球軌跡（`PT.vsWait`）也是整步暫停，所以兩台的「步數＝模擬時間」。
- **所有輸入都是 tick 事件**：`VS.tickAct(kind,args)`＝排在 `ck+5`，兩台在同一步套用（事件表 `VS.H`）。包含：投球 PITCH（取代舊的 pitch/lock/延遲 D）、短打 BUNT、ABS 挑戰 ABS、換投／代打／代跑／換守／戰術／盜壘／牽制／止滑粉／訪視（`vsAct`，只能在投球前）、推進／退回／傳球／手動守備（PUSH／RET／THROW／FMSEL／FMV）。每個事件套用時用 `hash(seed,who,seq)` 重設亂數。
- **揮棒**：仍由打者那支手機判定（因為用到鏡頭），訊息 `swing`／`take`／`ptsnap`；對手收到後套用。
- **房主校正**：房主每 5 步送 `st`（出局／球數／比分／各跑者／各守備員位置／球進場狀態），訪客拿「同一步的自己」（`VS.rec`）比對：位置差多少補多少（`correct`），出局／球數／比分直接覆蓋。每球開始 `ready` 另帶 `fs`（壘上名單、比分…），訪客用 `fixBases` 把跑者移到房主那一壘。無法修復的差異（跑者狀態不同等）會記在 `VS.diag`，畫面上方「同步校正中」點一下可看最近 8 筆。
- **ABS**：大廳可開關。連線時 10 `absFlow`、06 `absJudge` 以「被誤判那隊」為挑戰方，面板只在該隊手機出現（`absPanelOn`），按鈕輸入走 ABS tick 事件；抗議小遊戲與電腦挑戰在連線時關閉。
- **手動守備／天氣／大廳設定**：同第二版（天氣仍是每球開始兩台用同一組種子推進）。
- **測試**：`node tests/test-lockstep.js`（雙沙盒、有序通道、隨機延遲；檢查事件同步與房主校正）。
- 對戰中 `body.vsx`（不再用 `body.vs`）。

## 第十九版更新：全檔對照整理（`sw.js` VERSION v69；本次只改文件，沒有改任何遊戲檔）
- **對照範圍**：`baseball.html`、`sw.js`、`yw_manifest.json`、`css/01`～`08`、`js/01`～`14`（含 `13b`～`13p`）、`js/vendor/qrcode.min.js`、`js/vendor/jsqr.min.js`。已確認本檔所列的函式、欄位、鍵名都能在對應檔案找到（語法層級；**沒有在瀏覽器實機驗證**）。
- **新增／補上的說明**：JS 表格補 `13p`；CSS 表格補 `08-versus.css`；PWA 表補 `js/vendor/`、圖示、`js/three.min.js`；`13b` 的「存檔同時寫入裝置檔案」；`14` 的區網對戰入口；任務表補 13n／13o／13p；`sw.js` 版本更正為 v69；續約／多年度已完成的標題更正；新增下方「瀏覽器儲存鍵一覽」。
- **`baseball.html` 實際載入順序**（與檔名編號略有不同，這是目前可正常運作的順序，不要隨意重排）：`01`～`12` → `13` → `13b` → `13c` → `13d` → `13e` → `13f` → `13g` → `13j` → `13h` → `13i` → `13k` → `13m` → `13l` → `13n` → `13o` → `13p` → `14`。`#curtain` 在最後一個 `<script>` 之後、`</body>` 之前；`sw.js` 註冊用 `updateViaCache:'none'`。
- **已知問題（尚未改）**：`css/08-versus.css` 的 `body.vs …{display:none!important}` 規則失效（13p 只加 `vsx`，且沒有程式加 `vs`）。目前對戰中那些按鈕**不會被隱藏**；若本意是隱藏，要把選擇器改成 `body.vsx`，並先確認哪些按鈕在鎖步版本仍該保留（盜壘／牽制／換投／戰術等已是鎖步事件，ABS 也已開放，不應再隱藏）。
- **測試實跑**：本次實際執行了上傳的 21 支測試（結果見「測試腳本」表）：17 支通過（含 `test-webrtc-pairing`，需 `npm install werift`）；`test-lockstep`（路徑）與 `test-manual-fielding`（缺 `vsOn`）是測試檔本身過時，補一行即可通過；`test-update-check` 假通過（沒有執行任何斷言）；`test-protocol-harness` 為舊除錯檔。
- **歷史版本缺口**：`sw.js` 從 v63 到 v69 之間的變更沒有逐版紀錄（本次只能確認現況與版本號）。往後每次改檔請在本檔補一段並同步 `VERSION`。
- **13m 分頁**：第一個分頁已由「總覽」改為「🏠 主畫面」（`pageHome`），其餘六個不變，共七個。
- **事件數**：`13h` 實際載入後 `CSTORY.all()` 為 46 個（與本檔相符；pro_start 17／after_game 15／season_end 2／po_series 3／po_end 3／offseason 6）。`13k` 場景 25 個、`13f` 快轉速度 `SPEEDS=[40,80,160]` 亦相符。
- **同名重複（維持不動）**：`mkRng` 仍在 `03`、`04` 各一份；`practiceSwing` 仍在 `11`、`13` 各一份。

## 瀏覽器儲存鍵一覽（localStorage／IndexedDB；備份、清除快取、改鍵名前先看這裡）
| 鍵／資料庫 | 用途 | 所在檔 |
|---|---|---|
| `cpbl2027.save.<normal\|career>.<1~3>` | 存檔欄位 | 13b |
| `cpbl2027.career.profile.<1~3>` | 生涯角色 | 13c |
| `cpbl2027.career.season.<角色id>` | 生涯賽季／歷史（含 `SS.pro` 全部欄位） | 13d |
| `cpbl2027.assistDef` | 輔助防守偏好 | 13g |
| `cpbl_filesave` | 存檔寫入裝置檔案開關（`'0'`＝關） | 13b |
| IndexedDB `cpbl_guard`（store `h`） | 各存檔欄位的「檔案位置」代碼 | 13b |
| `cpbl_sg_last`、`cpbl_sg_auto` | 上次備份時間、自動備份設定（**不會被備份進檔案**） | 13n |
| IndexedDB `cpbl_sguard`（store `h`） | 整份備份用的自動寫入檔案位置 | 13n |
| `cpbl.updMsg`、`cpbl.ver` | 更新提示、上次記錄的版本 | 13o |
| `cpbl_bgm_mute／track／v2／vol`、`cpbl_sfx_mute／vol` | 音樂音效設定 | 08、13 |
| `cpbl_hint`、`cpbl_vib` | 提示、震動設定 | 13（11） |
- **13n 的整份備份**＝整個 localStorage（除 `cpbl_sg_*`）；`hasSave()` 以「鍵名開頭 `cpbl2027`」判斷有沒有存檔，所以存檔鍵一律要用 `cpbl2027` 開頭，否則「3 天沒備份」提醒不會觸發。
- **13o 強制更新**只清 Cache Storage（`cpbl2027-*`）與 Service Worker，**不碰**以上任何鍵。


## 三振強化（13q＋03／09／11／07css 小改）
- **K 數**：`09` 的投手面板在「球數」後加 `K n`（`Math.max(p.kx, p.kA)`）；`13q` 包住 `finishAB`／`pitchResult` 計 `p.kx`（用 `b._kc` 防重複）。**注意**：`13d` 讀 `me.kA`；`kA` 在 `12-systems.js` `abMood` 累加（已查明）。
- **回放**：`start(info)` 在 `pitchResult` 偵測到三振後 `after(1.15)`（第三出局 `.9`）觸發；`nice()` 決定要不要播（揮空必播；看三振需球速≥148／得點圈／結束半局）。偏好 `localStorage cpbl2027.krep`（'0'＝關，回放畫面右下按鈕可切）。鏡頭用 `CAMC.mode='rcam'`（同 13l）。結束後還原姿勢／球／鏡頭。
- **空揮**：`11` 揮空判定處呼叫 `KFX.whiff()`（風聲、鏡頭震動、頓格、「呼～！」）；`03` 的揮空姿勢加大（`1.15*wh`、`.9*wh`、`whx .62`）。
- **懊惱**：`11` 的 `pitchReact('K')` 改呼叫 `KFX.react(打者)`，失敗才退回舊的 `headdown`。動作 `bk_slam／bk_snap／bk_drop／bk_stomp／bk_shake／bk_pound` 寫在 `03` 的動畫 switch（疊在 stance 姿勢上），棒子生成／物理在 `13q`（`toss`／`snapBat`／`physics`）。
- **結算排版**：`07-career.css` 末尾用 `#result:has(.cr-resdock)` 改為球員卡（左）＋結算內容（右）橫排、可捲動；直向手機改直排。`.cr-resdock` 不再 absolute。
- **未在瀏覽器實機驗證**：僅 `node --check` 與 vm 假環境 smoke 測試（K 計數、排程、react、無錄影時安全退出）。見 HANDOFF.md。


## 版本號規則（從 v1.1.5 起）
- `sw.js` 的 `VERSION` 改用 `v主.次.修` 格式，目前 **v1.1.7**（原本的 v69／v70 流水號停用）。
- 每次改版（改了任何 css／js／images／baseball.html）**只加最後一位**；最後一位到 9 後歸 0，前一位 +1，再往前依此類推：`v1.1.8 → v1.1.9 → v1.2.0 → … → v1.9.9 → v2.0.0`。
- 快取名稱 `cpbl2027-` + VERSION 會跟著變，所以舊快取仍會在 activate 時被清掉。
- **已確認（13o 已上傳檢查）**：`13o-update-check.js` 用 `/const\s+VERSION\s*=\s*'([^']+)'/` 讀版本字串，並用 `===` 字串比對、原樣顯示（「已更新至最新版本 v1.1.5」），所以 `v主.次.修` 格式相容，不需修改 13o。注意：sw.js 內不要在 `const VERSION =` 之前寫出同樣樣式的文字，否則會被先抓到。


## 第二十版更新（生涯故事擴充，sw.js v1.1.6）
- **13h `CSTORY`**：事件 46→77（`Ev` 50＋`register` 21＋`FR` 6）。新增：春訓；首安／首轟／十轟／三成／低潮；首勝／首救／十勝／百三振／被打爆；明星賽入選（`PRO_ALLSTAR_PICKED`，`PRO_ALLSTAR_BREAK` 改為「沒入選」才播）；傷病四件（輕／中／重／復出）；疲勞（`PRO_FATIGUE`，cooldown 25 場）、存款；教練／前輩／隊友關係回收；對手三連（INTRO→REUNION→FINAL）；導師／球迷／經紀人舊選擇回報；MVP／新人／表揚之夜。`RELN` 擴充，`mkChoice` 支援 `mood`／`fit`／`flags:{}`。
- **13e `storyExtra`**：補 ctx（kind、season、career、inj、healthy、rel、award）；有 13i 時 adapter 多 `fit`；`buildStory` 補新旗標句。
- **13k `CSCENE`**：`BY_ID` 為 31 個新事件對應**既有**場景（借用，尚無專屬場景；專屬場景與回顧動畫列為下一步）。
- **開季事件順序變化**：第一年開季現在是「第一次站上一軍」→「春訓營」→ 賽前畫面（春訓營 `pro_start`、`season.g >= 0`）。
- **測試同步（第二十一版接手時補）**：`test-career-integration`（補春訓營一步）、`test-career-market`（換隊信賴度容許春訓營 +0～1）、`test-lockstep`（13p 路徑改 `js/`）、`test-manual-fielding`（mock 補 `vsOn`，13p 加入後遺漏）。
- **已知未解**（第二十二版已查明，見檔尾）：`tests/test-protocol-harness.js` 失敗（`PTget()` 回 null、投球未發生）＝舊除錯工具過時，不是 13p 問題；`tests/test-webrtc-pairing.js` 需 `werift` 套件，環境未安裝，未執行。
- **壓縮檔缺 `CLAUDE_PROJECT_RULES.txt`**；`files.zip`（內含舊版 sw.js／FILE_MAP.md／HANDOFF.md）與外層檔案同為 v1.1.5 內容，已不代表最新版。
- **未在瀏覽器實機驗證**，僅 `node --check` 與 Node 假環境測試。


## 第二十一版更新・階段 A：專屬場景（sw.js v1.1.7）
- **13k**：新增 28 個專屬場景（springcamp firsthit homer flamebat slump firstwin wins10 closer kboard shelled asgnames icepack crutch hospital rehab tired piggy vote rival rival2 rival3 mentor letter deal phone mvp rookie awardnight），`BY_ID` 把第二十版 29 個事件改指向它們（`PRO_COACH_PAYOFF`／`PRO_VET_LEGACY` 沿用 coachroom／locker，本來就是專屬場景）；`CAP` 補中文標題。場景圖上只放英文／數字，不放戰績。共用小零件 `txt／moundAt／trail／flame／board` 只在 13k 內。
- **新測試** `tests/test-story-scenes.js`：每個 13h 事件都有 BY_ID、場景存在、SVG 合法（87 項）。
- 驗證：Playwright 把 28 個新場景逐一渲染截圖目視檢查（全部可正常顯示）；**未**在遊戲內實機（13e 的 `storyGate`）看過。

## 第二十一版更新・階段 B：動畫與真實戰績標籤（sw.js v1.1.8）〔重建版〕
> 註：原 v1.1.8／v1.1.9 檔案遺失，本段與下一段是依 HANDOVER_第二十一版.md 在 v1.1.7 基礎上**重建**（行為依交接檔描述，程式碼不會與原版逐字相同）。
- **13k**：新增 `FX` 動畫（`FXG`／`FXMAP`／`fx(k)`）：confetti 彩帶、ball 球軌跡、flash 閃光、cheer 看台歡呼、burst 煙火、kcard 三振牌翻開（圖上只有英文 `K`）、ecg 心電圖、rain 雨；26 個場景對應動畫（trophy mvp rookie firstwin wins10 firsthit homer flamebat hot spot allstar stands asgnames day fire farewell kboard closer hospital icepack crutch rehab tired empty shelled slump）。
- 「略過」鈕（`.stSkip`，document 層 click 委派，只加 `.stSkipped` 隱藏動畫，不影響事件選項／存檔）；`prefers-reduced-motion` 時動畫與略過鈕隱藏；沒有動畫的場景不出現略過鈕。
- `stFact` 真實戰績小標籤：`factText(facts, sceneKey)`，只用傳入的 `storyCtx()` 欄位（year／season／career），缺資料的項目整個不顯示，不內建任何數字；輸出經 `escH` 跳脫。
- `CSCENE.html(ev, ph, facts)` 多第三參數；`block(k, facts)` 為共用的場景區塊產生器。對外多了 `fx`、`factText`、`fxMap`。
- **13e**：`sceneHtml` 把 `storyCtx()` 當 facts 傳入（包 try／catch，出錯回空字串）。

## 第二十一版更新・階段 C：退役精采回顧（sw.js v1.1.9）〔重建版〕
- **13k**：`recap(P, {kind,name,teamName,title})` 只用 `P.hist`、`P.story.log` 產生投影片資料（起點→里程碑／各年→告別，最多 12 張；超過時優先保留冠軍＞獎項／里程碑）；`recapPlay(mount, slides, onEnd)` 播放（每張約 3.4 秒、「下一張」「略過回顧」、播完 `onEnd` 只呼叫一次、畫面被換掉靜默停止、出錯安全略過並呼叫 `onEnd`）。里程碑事件清單 `MILE`。
- **13e**：`retireRecap(kind)`、`playRecap(kind)`、`showRetire(kind, replay)`（`'again'`＝重看、`'done'`＝播完）；只有「剛退役」或按「🎞 重看精采回顧」才播，已退役存檔再進入不自動播；13k 缺席或出錯時直接顯示生涯回顧。**沒有新增存檔欄位。**
- **新測試**：`tests/test-story-recap.js`（13k 純邏輯，85 項）、`tests/test-retire-recap.js`（載入真正的 13e＋13k，17 項）。
- 驗證：Node 測試全部見交接檔；**未**在真瀏覽器／完整遊戲實機驗證（動畫視覺、手機直式、真實退役流程）。

## 第二十二版更新：測試修補（只改測試與文件，沒有改任何遊戲檔；`sw.js` 維持 v1.1.9）
- **取得專案的方式**：`project.rar` 為 RAR5，容器沒有 unrar／7z、不能上網，改用自寫的 Python RAR5 解壓器，70 個檔案 CRC32 全部通過。壓縮檔內的 13e／13k／sw.js／FILE_MAP 已是重建版 v1.1.9（含 `recap`／`recapPlay`／`factText`／`retireRecap`／`playRecap`）。**原版 v1.1.9 仍未取得**，若找到以原版為準。
- `tests/test-career-market.js`：「A3 二軍」區塊開頭補 `P.injury=null;`。偶發失敗（「板凳下放二軍實際 12 場」）在這次連跑 20 次（修補前）與 20 次（修補後）都沒再出現，**修補是否有效未能證實**。
- `tests/test-update-check.js`：改寫為 14 項真斷言。原因：測試假 `setTimeout` 不觸發，13o 的 `await sleep(800)` 永遠不完成；版本號正則 `/'v\d+'/` 對不上 `'v1.1.9'`；13o 現在在沒有新 SW 安裝時 4 秒後自動強制更新、有安裝中則等 `controllerchange`，提示文字為「新版本已就緒」、重載延遲 1500 ms。`force(true)` 不被 `check()` await，測試要稍等。**這些判斷來自讀 13o 原始碼與假環境，沒有在真瀏覽器驗證 Service Worker 行為。**
- `tests/test-protocol-harness.js`：失敗原因＝13p 現在把投球排進「共同時鐘＋5 步」（`VS.tickAct`），只在被包過的 `step()` 內執行；此舊工具的 `step` 是空函式。這是讀程式推論，未在副本驗證。檔頭已加「已過時」註解；請用 `test-lockstep.js`。
- `tests/test-webrtc-pairing.js`：`Cannot find module 'werift'`，需在有網路的電腦 `npm install werift`；此環境未執行。
- 工具提醒：不要用 `pkill -f <測試名>`（會比對到自己的指令列把 shell 殺掉）；含中文的檔案用 Python 切行。

## 第二十四版更新：新事件＋新場景＋回顧補完（`sw.js` VERSION v1.1.10）
- **13h**：新增 8 個事件（共 85 個）：`PRO_HIT_500`（生涯五百安打）、`PRO_HR_100`（百轟）、`PRO_WIN_100`（百勝）、`PRO_K_THOUSAND`（千次三振）、`PRO_TITLE_TWO`（第二座冠軍，po_end）、`PRO_TITLE_BANQUET`（冠軍慶功宴，po_end）、`PRO_KID_FAN`（場邊的小球迷，pro_start，需 `FAN_FAVORITE`＋第 8 年）、`PRO_HOME_TABLE`（回家吃飯，offseason，第 3 年起且需 `econ.mood` 欄位 ≤90）。**不新增存檔欄位、不改 13e。**
- **13h 引擎**：條件欄位新增 `seen.<事件id>.n`（該事件已選過幾次；`readField` 內），給「第二座冠軍」判斷用（`PRO_PO_CHAMPION` 第 2 次選完才出現）。po_end 同一時間點最多顯示 3 個事件：冠軍之夜→又一座冠軍→慶功宴剛好 3 個。
- **13k**：新增 10 張場景 `hit500 hr100 win100 k1000 parade banquet kidfan familytable benchslump fadeout`；`PRO_BENCH_SLUMP` 改用 `benchslump`、`PRO_RETIRE_DECLINE` 改用 `fadeout`（原先共用 `dugout`）。`FXMAP` 為 hit500／hr100／win100／k1000／parade／banquet／benchslump／fadeout 加動畫。`CAP` 補中文標題。
- **回顧（13k `recap`）**：`MILE` 加入 5 個新里程碑；新增 `STORY2`（重傷、傷後復出、先發低潮、打擊低潮、被打爆、宿敵三段、台灣大賽落敗）→ 優先序 1（冠軍 3＞獎項／里程碑 2＞這些 1＞一般年度 0），仍最多 12 張。只讀 `P.story.log`，沒有新存檔欄位。13d 社交層劇情與季後賽名場面（除決賽落敗外）尚未納入。
- **測試**：`test-career-story`（事件數 77→85、奪冠後會接慶功宴、新增 4 項共 62）、`test-story-scenes`（107）、`test-story-recap`（106，無動畫場景的測試改用 `PRO_MID_TEAMMATE`）。`test-update-check` 必須從專案根目錄執行（讀相對路徑 `sw.js`）。
- 驗證：Node 測試見交接檔；10 張新場景用 Chromium 渲染成圖目視過（`scenes-v1.1.10-preview.png`）；**未**在完整遊戲／真瀏覽器實機看過事件觸發與動畫。


## 第二十五版更新：測試修補＋二軍劇情調查（只改測試與文件，沒有改任何遊戲檔；`sw.js` 維持 v1.1.10）
- **`tests/test-career-integration.js`**：季後賽結局事件斷言改為「結局事件恰好一次；其後只能接『又一座總冠軍』『冠軍慶功宴』（僅你的球隊奪冠時），沒奪冠則結局事件必須是最後一個」。原因：v1.1.10 新增慶功宴排在冠軍之夜之後，舊斷言要求「在最後」，你的球隊奪冠的輪次約 20% 失敗（修補前 15 次失敗 3 次；修補後 40 次 0 失敗，其中 8 次為奪冠輪次；把允許清單清空的變異版 25 次失敗 8 次，證明斷言仍有效）。**這是測試過時，不是遊戲錯誤。**
- **二軍調查（只讀程式，未實機）**：`storyGate` 由 `showIntro`（13e 約 425 行）等主入口呼叫，**不分一軍／二軍**；`storyCtx0` 提供 `level`（`'farm'`／`'first'`）。13h 現有 85 個事件**沒有任何一個用 `level` 當條件**，所以二軍球員也會觸發一般事件（依 apps／season 等條件）。13h 的 `readField` 讀得到 `level`，新增二軍專屬事件只要加條件 `E('level','eq','farm')`，**不用改引擎**。二軍球員實際會不會遇到不合理的事件（例如「先發低潮」）尚未用模擬確認。
- **取得專案**：`rar5x.py`＋`rar5parse.py`（自寫 RAR5 解壓器，已放在交接包）；`python3 rar5x.py project.rar proj`、`python3 rar5x.py tests.rar proj`，CRC32 全過（專案 46 檔、tests 24 檔）。
- **二軍模擬結果（第二十五版後續；假環境、種子 1～3、各 6 年，只看「會不會觸發」，沒看文字是否合理、沒有實機）**：`tests/sim-farm-story.js`（不是斷言測試，檔名刻意不叫 `test-*`）。球員真正處於二軍（畫面顯示當下 `level==='farm'`）時，實際出現過的事件約 17 種：開季前的休息室、春訓營、更衣室的閒聊、明星賽週的空檔、球季尾聲的壓力、最後的衝刺、挑戰賽前夜、台灣大賽前夕、總冠軍之夜、冠軍慶功宴、年度表揚之夜、差一步的總冠軍／止步季後挑戰賽、休賽季的續約談話、第二個球季、教練的託付、另一個和你一樣的人、球季檢討、回家吃飯。**結論：二軍球員會看到整條主線，包含季後賽與冠軍事件。** 這些事件文字是否與二軍身分衝突（例如「最後的衝刺」「年度表揚之夜」）**尚未逐一讀文字確認**。
- **`awardsFor`（13e 第 381 行）把球隊奪冠也算成獎項**（`'🏆 台灣大賽總冠軍'`），所以 `award.any≥1`，`PRO_AWARD_NIGHT`（條件 `award.any≥1` 且非 MVP／新人）在球隊奪冠時，即使球員在二軍或沒上場也會出現，文字「你的名字出現在其中幾個獎項的名單上」與實際不符。**這是讀程式與模擬的推論，沒改、沒實機確認；可能是既有設計，要不要改請使用者決定。**

## 第二十六版更新：二軍劇情衝突修正 A＋B（`sw.js` VERSION v1.1.11）
- **A（13h）**：`PRO_PO_CH_EVE_BENCH`（挑戰賽前夜・板凳版）、`PRO_PO_FINAL_EVE`（台灣大賽前夕）各加條件 `E('level','ne','farm')`。二軍球員不在季後賽名單，原文「隨時可能把你叫上場」「上場以後只管眼前這一球」不適用；該時間點無事件時引擎會直接略過。
- **B（13e 第 191 行）**：`c.award.any` 改為不計入含「總冠軍」的標籤（`awardsFor` 把球隊奪冠當成獎項推入）。只有 `PRO_AWARD_NIGHT` 使用 `award.any`（已 grep 確認，js 與 tests 皆然），所以只影響它：球隊奪冠但沒有個人獎項時不再出現「你的名字出現在獎項名單上」。
- **注意（引擎規則）**：條件欄位缺值＝不成立，`ne` 也一樣。13e 的 `storyCtx` 一定提供 `level`；測試用的假 ctx 必須帶 `level`（`test-career-story` 的 `base()` 已加 `level:'first'`）。日後新寫的測試或假 ctx 若沒帶 `level`，這兩個事件不會出現。
- **測試**：`test-career-story` 62→64（新增：二軍不出現兩個季後賽前夜事件、一軍照舊；年度表揚之夜只在 `award.any≥1` 時出現）。完整回歸：除已知的 `test-protocol-harness`、`test-webrtc-pairing` 外 rc 皆 0；`career-integration` 連跑 30 次 30 通過。`tests/sim-farm-story.js` 種子 1～8、各 6 年：二軍球員碰到挑戰賽前夜／台灣大賽前夕／年度表揚之夜皆 0 次（一軍 10／13／16 次）。**這些都是假環境結果，沒有實機。**
- **沒有處理**（交接檔第三節）：「中」程度的文字衝突（差一步的總冠軍、止步季後挑戰賽、另一個和你一樣的人）與方案 C（新增二軍專屬事件）。


## 第二十七版更新：甲子園風外觀（`sw.js` VERSION v1.1.12；只改外觀，不動比賽邏輯）
- **新檔**：`js/13r-koshien-skin.js`（載入在 13q 之後、14 之前）、`css/09-koshien.css`（最後一個 css；規則都掛在 `body.ko`）。已列入 `baseball.html` 與 `sw.js` LOCAL。
- **還原方式**：`13r` 開頭 `KO.on=false`（或不載入 13r＋09 css）即回原樣；原本的 `#bso／#sb／#pinfo`、`updateLamps／updateScoreboard／updatePlayerBoxes` 都還在，只是 `body.ko` 時以 CSS 隱藏。
- **場景**：重畫 `grassTex／skinTex／adTex／crowdTex`（近黑內野土、橄欖綠草、深綠牆與看台、灰色樑柱）；`scene.background` 改成陰天雲層貼圖；包住 12 的 `applyLighting`（日夜／天氣一律用陰天色調，雨天仍會變暗）、`updateNight`（隱藏夜空／燈塔）、`applyPark`（重擺看板）、`drawSky`（改成淡暗角）；隱藏屋簷、燈塔、警戒區；新增 PLAY BALL／BASEBALL 橫幅、KOSHIEN 計分板（`koDrawBoard` 用 `G.line` 逐局畫）、時鐘與「甲子園」招牌、打擊區青色光暈（`koGlow`）。
- **球員**：包住 `makeChibi`（13d 之後再包一層）：頭放大 12%、眼睛放大並加高光、帽／頭盔加高光。
- **HUD**：`#koHud`（右上比分板、HOME／AWAY 打序、左側壘包菱形＋「N Out」、右下打者／投手資料），資料只讀 `G`、`curBatter()`、`curPitcher()`。電腦版 `#acts／#touchBtns／#pitchPanel` 往上讓出右下空間，`#caption` 右側留白加大。
- **擊球框**：改寫 `drawBat`（青色半透明方框＋淡淡的實際球棒判定輪廓與甜蜜點帶；判定邏輯完全沒動）；`drawOverlay` 暫時攔截好球帶外框 `strokeRect`，改畫白框＋四角三角。
- **未在瀏覽器實機驗證 3D 畫面**（環境沒有 three.js）；HUD 用假資料頁面截圖檢查過版面。

## 第二十八版：甲子園風修正（`sw.js` VERSION v1.1.13）
- `13r`：眼睛高光球原本放大過頭，在臉前變成一片白，已縮成小點；頭上高光改貼在帽／頭盔弧面。
- `13r`：看台是斜面，看板／計分板／時鐘原本垂直擺放、下半部埋進看台，現在改成貼著斜面（法線朝場內＋朝上）。
- 未實機驗證 3D 畫面。

## 第二十九版（v1.1.14）
- 13r：後方計分板標題改為 CPBL 2027；左欄顯示兩隊全名（G.teams[s].name），欄位加寬。

## 第三十版（v1.1.15）
- 13r：新增看台頂端鐵絲網、遠方山丘；角色表面改 Phong 柔和高光、頭再大一點；09 css 面板質感。

## 第三十一版更新（與甲子園風 v1.1.15 整併）：結算畫面排版確認＋桌機 K 數＋更多懊惱動作（`sw.js` VERSION v1.1.16）
- **接手時發現**：`project.rar` 內已含 13q 三振強化（K 數、回放、空揮、懊惱），但從沒在瀏覽器驗證，且桌機投手面板（`09` 的 `#pS` 那行）球數旁**沒有 K**，只有手機精簡面板 `#pC` 有。
- **09**：`#pS` 在「N 球」後加 `K<b>n</b>`（`Math.max(kx,kA)`）；`css/07-career.css` 加 `#pS .kc` 樣式。
- **13q**：`addK` 之後立刻呼叫 `updatePlayerBoxes()`，三振當下面板就更新（原本要等下一打席）。`KINDS` 由 6 種增為 10 種：新增 `bk_sigh`（無奈：垂頭嘆氣搖頭、球棒垂下）、`bk_scream`（不甘心：仰天怒吼雙臂高舉）、`bk_kick`（猛踢打擊區的土）、`bk_glare`（轉身瞪人握拳）。
- **03**：動畫 switch 的 `bk_*` case 加上述 4 個（純姿勢，疊在 stance 上，沒有新 3D 物件）。
- **結算畫面排版**：`13c attachResult` 對 `#result` 加 `.crdock`；`css/07-career.css` 改為 `#result.crdock`（不靠 `:has`）：橫向＝左卡右內容、直向手機＝上方橫條卡＋下方內容、矮螢幕縮小、內容太高整頁可捲動。`css/03` 的 `.rbox` 加 `max-width:100%`、`#result` 加 `overflow-x:hidden`（窄螢幕不再橫向溢出）。
- **新測試**：`tests/test-strikeout-fx.js`（23 項，假環境：K 不重複計數、短打三振、vs 模式、回放排程／播放／還原、10 種懊惱動作、桌機＋手機面板含 K）；`tests/test-result-layout.js`（Playwright＋Chromium，40 項：4 種情境×10 種螢幕尺寸，球員卡不遮擋 MVP／獎項／比分／按鈕、無橫向溢出）。
- **驗證範圍**：Node 假環境＋Chromium 渲染結算畫面。**未**在完整遊戲實機看過（本環境沒有 three.js、不能上網）：慢動作回放的畫面、空揮特效、新舊懊惱動作的肢體表現、桌機 K 數位置。請實機看過再調整。
- **回復**：`js/09-hud-commentary.js` 第 61 行去掉 K 片段；`js/13q` 還原 `addK` 與 `KINDS`；`js/03` 去掉 4 個 `bk_*`；`css/03` 兩處、`css/07` `#pS .kc`；`sw.js` 改回 `v1.1.15`。沒有新增存檔欄位。
- 整併備註：甲子園風 `13r` 的 `#koHud` 本來就讀 `Math.max(kx,kA)` 顯示 K，與本版 K 數一致；`body.ko` 隱藏 `#pinfo`，所以 `#pS` 的 K 只在非甲子園外觀可見。

## 第三十二版（v1.1.17）：LED 計分板隊名＋坐滿觀眾的看台
- **13r `koDrawBoard`**：中央計分板改為黑底 LED 點陣（`koLed`：把文字縮小畫在暫存畫布，再依亮點畫成發光圓點；底圖有熄滅的點陣、只畫一次）。**最上排＝目前對戰兩隊全名**（左隊／VS／右隊，用各隊 `c1` 隊色，太暗的色會往白混合 `koLedColor`），其下 TEAM／1～9／R H E、兩隊簡稱與逐局得分、底部 `CPBL 2027` 與目前「▲／▼ 局數」。貼圖 1024×360 → 2048×720（`koBuildDecor`）。重畫條件的 key 加入隊名／簡稱／隊色。
- **13r `koRedrawStand`**：看台貼圖由 1024×256 放大為 2048×1024，整面畫滿 Q 版觀眾（隊色與雜色球衣、膚色、球帽／髮、約 5% 空位、偶爾舉手與小旗、長條加油布條、階梯面與灰色樑柱）；下排蓋住上排。原本只有很淡的點，看起來是空看台。
- 驗證：用 Chromium 把兩張貼圖畫出來目視（貼圖本身）；**未**在有 three.js 的完整遊戲看 3D 貼合、遠近縮放時的觀眾清晰度與計分板大小。
- 回復：`13r` 兩個函式與 `koBuildDecor` 的貼圖尺寸還原為第三十版；`sw.js` 改回 `v1.1.16`。


## 13r 外觀修正 v2（計分板／球場名稱／天空／牆面廣告）
- **看台縮小**：`KOS = {D:19, H:10.5}`（原 34／24 會把天空全部蓋住）。`koApplyShape()` 在 `koSceneInit` 與 `applyPark` 後重建 `stand`、`wall` 幾何並重畫牆面廣告；`koRing()` 的貼圖週期調成繞一圈整數次（中外野不再有接縫）。
- **牆面廣告**：`koRedrawWall()` 依 `WALL_H` 算每公尺像素，廣告只畫在 1 公尺護墊以上；字太寬時縮小字級而不是橫向壓扁。原本浮在看台上的彎曲贊助橫幅移除，改為參考圖的 PLAY BALL／BASEBALL 平板。
- **後方看板**：計分板、招牌、時鐘改用 `koBandGeom()`（與看台同圓心的垂直圓柱面，微後傾 `L=.16`），三者共用 `hs=bh` 疊在同一條軸線上；舊的 `koBendPlane` 逐頂點推擠已移除（那是計分板扭曲的原因）。計分板內容見 `koDrawBoard()`（球場英文名 `KO_EN`、逐局比分、R/H/E、S/B/O 燈）。
- **天空**：`koSkyTex()` 改為 fbm 多層雲（2048×1024）。夜間 `RIM` 光點也一併隱藏（原本會浮在舊看台高度）。
- 還原方式不變：`KO.on = false`。


## 第三十三版（v1.1.23）：捕手接球位置一致＋球的尾勁＋揮棒／擊球感（沒有新增檔案，改 03／04／11／13q）
- **接球位置不一致的原因**：球的終點（`pt.fx／fy`）本來就正確，但 03 的 `'catch'` 動作固定把手套舉到約 y=1.85（手臂 -2.4 弧度、身體站直），完全不看球落在哪；而且 0.3 秒後就收手站起來，球卻還停在原處。球落在下緣時就變成「捕手在上面接空氣」。回放（13q）只是錄下同一套姿勢，所以同樣錯。
- **04**：新增 `mittPoint(pt,out)`＝球飛行的最後一點（沿視線移到手套深度）。球的飛行、捕手手套、`catchX` 都吃這一個點。新增 `TAIL_K`（預設 1.16）：把各球種的變化再往後段推，終點不變。要退回舊手感把 `TAIL_K` 改 1。
- **03**：`solveCatchPose(r,T)`（掃描手臂角度／前傾／蹲高，找手套最靠近球終點的姿勢，結果依 y、z 快取在 `r._cgc`）、`catcherPose`（`'cset'`＝球飛到一半手套先移到位、`'catch'`＝接球瞬間手套被頂一下再回正，球跟著手套動；接住後 `hold` 到捕手回傳，超過 2.4 秒保險回蹲姿）。手套本體會在手臂座標內微調（上限 .34 公尺）貼到球的位置，`r._gBase` 存預設位置，離開接球動作由 `rigStep` 還原。**只有帶 `opt.cg` 的捕手接球走新路徑**，投手／野手的 `'catch'` 維持原樣。
- **03 揮棒**：`bsParams('swing')` 加速段改為「越揮越快、擊球點最快」（原本是對稱 smoothstep，擊球瞬間速度＝0）；身體 `by` 比手／棒頭 `th` 早轉（鞭打）；送棒從擊球點速度順勢帶出。**擊球瞬間（u=.5）的 th／tl／by 數值沒變**，所以判定與擊球點不受影響。新增揮棒殘影 `swishAdd`、衝擊環 `spawnRing`、擊球後棒身餘震 `rig.batShake`（依擊球品質）。`TRAIL_N` 18→26。
- **11**：`updateFlight` 的 `cprep` 先解手套姿勢；`catchX` 改成讓「手套」（不是身體中心）對準球；`catcherCatch` 用 `pt.cT`（同一個點）、接球 `hold`；被打出去（`handleSwing` contact）或觸身球時把 `'cset'` 還原成蹲姿；`pitchFx` 越接近本壘拖尾越長越亮；`hitFeel` 加衝擊環與棒身餘震。
- **13q**：`NODES` 加入 `'glove'`，回放才會重現手套被帶到球位置的姿勢。
- **驗證**：Node 假環境（自寫極簡 THREE 替身＋從 03／04 直接抽出的真實函式）——手套與球終點誤差 ≤ 0.001 公尺（8 種落點含最低 y=.3、最高 y=1.6、左右 1.4）；舊 `catch` 動作手套高度 1.85；球飛行最後一點與 `mittPoint` 誤差 0。**未**在有 three.js 的完整遊戲看過：揮棒姿勢的實際外觀、殘影／衝擊環亮度、手套比例是否自然、捕手身體前傾後仰的幅度。
- **回復**：`sw.js` 改回 `v1.1.22`；`TAIL_K` 設 1；03 內 `'cset'／'catch'` 那行還原成舊的單行 `'catch'`；11 的 `cprep`／`catchX`／`catcherCatch` 還原；13q `NODES` 去掉 `'glove'`。



# 平衡調整紀錄（v1.1.24～v1.1.28，整合自修正包）

> harness 在 `harness/`、歷輪 diff 在 `diffs/`、各輪交接在 `docs/`。以下為修正包的說明。


## 第三十六版（第五輪）：量測驗證，遊戲檔未改（`sw.js` 維持 v1.1.25）
- 沒有改 04／05／sw.js。修了 harness 的強打模式（`mc.js`／`mc2.js` 的 `const prof` 重新賦值錯誤），新增 `harness/diag.js`。
- 第四輪現況重量：C 頂尖 good HR 約 7.9～8.2%（非 7.7%）；38 以上係數 .4 與 FB 兩種調法（門檻 32／基準仰角 3.5）皆在雜訊內，未採用；強打模式 A／B HR 3.7／8.8%。詳見 HANDOFF.md（第五輪）。

## 第三十七版（第六輪）：守備變靈敏（sw.js v1.1.26）
- 只改 05：移除 react +.07、內野隨機慢半拍；setT.wait 縮短；reach 基準 1.2→0.7 補回安打率。詳見 HANDOFF.md。

## 第三十八版（第七輪）：外野高飛球落點判斷誤差（sw.js v1.1.27）
- 只改 05：外野 readErr（ang>14）倍率 1→3.5，補回 fb 安打率；詳見 HANDOFF.md。
- harness 新增：mc3.js／load3.js／suite3.sh（電腦打者 aiBatPlan）；mc2.js 新增 LV 環境變數（電腦方守備量測）。

## 第三十九版（第八輪）：遊戲檔未改（sw.js v1.1.27）
- 只改 harness/mc3.js（揮空／界外／界內拆分）。

## 第九輪
- harness/diag_ld.js：mc2 + LD 診斷。遊戲檔未改。
- 04：仰角行已加 R9 註解（changes-round9-04.diff）；sw.js VERSION v1.1.28。


## 第四十一版（v1.1.29）：受傷倒地野手、滑壘動畫、手機比分板
- 05：`holderThink` 受傷（pl.out）的持球者不再被選為「自己持球跑壘」，改傳給隊友；`moveFielder` 受傷倒地（anim `down`＋hold）的野手原地不動，不再趴著滑行。
- 13g：撲接（`dive`）／倒地（`down`）動作中或已受傷的野手，玩家不能操控移動，動作結束才恢復。
- 03：`slide`（腳先）改為上身後仰約 45°、領先腳前伸、另一腳彎曲、雙手舉起；`hdive`（頭先）改為胸口微抬、雙手前伸、雙腳彎曲後收（原本兩者都近乎平躺在地）。
- css/09：手機（`body.ko.mob`）比分板 `#koTop .tm` 被 07-career.css 全域 `.tm` 誤套 padding／gap 而縮高、裁字；已歸零並讓比分板疊在選手卡之上。桌面版不變。
- diff 見 `diffs/changes-v1.1.29.diff`。


## 第四十二版（v1.1.34）：球員表情系統（新增 `js/13t-face-expression.js`）
- 新檔：`13t-face-expression.js`（`baseball.html` 在 13s 後、14 前加載入標籤；`sw.js` LOCAL 加路徑、VERSION v1.1.33→v1.1.34）。**沒有改動任何其他 js／css**，也沒有新增存檔欄位。
- 原本的眼睛／眉毛／嘴巴只是被隱藏（`visible=false`），鼻子、鬍子、墨鏡、眼下黑貼、耳環等不動。13r 加在眼睛旁的白色小高光球也會被隱藏（改用本檔高光）。
- 驗證：Node＋Chromium 假 THREE 環境——7 種眼型 × 31 種表情預設 × 全部動作名稱（`FX_ANIM`）逐幀更新無 NaN／無例外；遠近降級、快轉略過、視線追球、原五官隱藏皆通過；31 種嘴型畫布目視確認。**未**在有真 three.js 的完整遊戲看過 3D 貼合（眼睛／眉毛貼在球面上的位置、眼瞼與頭部的色差、遠近縮放時的大小）。請實機看過再調：眼睛大小在 `faceBuild` 的 `sx／sy／ix／iy`、眉毛高度在 `fxApply`、嘴型在 `fxDrawMouth`。
- 回復：`FACE.on=false`，或拿掉 `baseball.html` 的 `<script>`、`sw.js` 改回 v1.1.33。

## 第四十三版（v1.1.35）：球進手套不再上飄＋野手更快更好接（改 04／05／06／11，沒有新增檔案）
- **球過本壘後上飄（回放特別明顯）**：04 的 `pitchPosEx`／`mittPoint` 原本把球「沿鏡頭視線」移到手套深度，鏡頭在高處（bat 鏡頭 y=4.6）時世界座標會被抬高約 .5～.7 公尺；正後方看不出來，換到側面／投手視角／13q 回放就變成球進了好球帶後自己往上飛去手套。現在新增 `mittLerp(pt,u,out)`：從進壘點沿末段飛行方向延伸（左右 ±.1、上下 -.14～+.1，最低 .28），與鏡頭無關。球、捕手手套（`solveCatchPose`）、`catchX`、回放錄影都吃同一個點，所以一致。`rayAtZ` 保留（目前無人呼叫）。
- **捕手更早就位**：11 的 `cprep` 由球飛到 50% 提前到 35%，捕手更早橫移、手套更早舉到球的終點。
- **野手跑速（只改執行、不動規劃）**：05 `moveFielder` 在球飛行／滾動時，追球野手跑速×`EXEC_K_IF`(1.24，內野)／`EXEC_K_OF`(1.1，外野)、加速度×1.4，其他野手×1.1；手動操控（`f.manual`）與持球者不受影響。`planFielding`／`fspeed`／`MOVEK` 都沒動，所以安打／接殺機率基準不變。內野手追高飛球起步等待 .28→.16。
- **接球判定放寬（06 `updatePlay`）**：滾地球 `nearBall` 1.0→1.4 公尺（球距 1.4→1.9、高度 <1.4→<1.6）；高飛球 2.0→2.5 公尺；`chase` 1.3→1.7／1.2→1.6；沒接到改追球的延遲 .15→.3 秒。
- **驗證**：只做了語法檢查（`node --check`）。**未**在瀏覽器實測；請看回放球路是否自然、內野安打率是否明顯變少，必要時調 `EXEC_K_IF／EXEC_K_OF` 或 06 的門檻。
- **回復**：`sw.js` 改回 v1.1.34；04 的 `pitchPosEx`／`mittPoint` 改回 `rayAtZ`；11 `.35`→`.5`；05／06 還原上述數字。

## 第四十四版（v1.1.36）：牽制更像真的＋壘包旁牽制鈕（新增 `js/13u-pickoff-buttons.js`；改 05／11／baseball.html／sw.js）
- **新檔 13u**：玩家投球時，每個有跑者的壘包旁各一顆「牽制一／二／三壘」鈕（壘包 3D 位置投影到螢幕；在畫面外就貼邊加箭頭）；離壘 >2.4 m 的跑者按鈕變紅脈動。點擊直接呼叫 11 的 `doPickoff(i)`；投球前（pre）與「還沒抬腿」的出手動作中（windup 且 !G.legUp，含跑者已起跑／探頭）都能按。區網對戰（vsOn）不啟用、沿用舊鍵；鍵盤 E 照舊。啟用時 `body.pkOv` 把舊 `#btnPick` 藏起來。已加進 baseball.html（13t 後）與 sw.js LOCAL。
- **11 `doPickoff`**：壘包手不再慢慢走回壘（衝刺速度×2.0＋起跑初速 3.8，投手站定 .7→.3 秒，不等到位才傳；`el≥.14` 且距壘 <2.6 m 即傳，最多等 .55 秒）；傳球動作 .36→.3、球速×.8（最短 .22 秒）、撲壘動畫變短、揚塵依離壘距離加大、傳球時鏡頭微震、離壘大者跳「牽制！」提示；二壘由離壘包較近的 SS／2B 去接；跑者警戒度增量 .32→.4（離壘 >2.6 m 再 +.14）。
- **05**：警戒跑者離壘縮短幅度 .35→.5（牽制的嚇阻力）。
- **未動／待確認**：舊牽制鈕的原處理程式與 `pickoffSuccess`／`pickAbility`／`aiPickoffThink`／`stealIntent` 在未上傳的檔案（推測 07／12／13）；13u 假設舊鈕只是呼叫 `doPickoff`。若舊鈕還有牽制次數限制等規則，請把處理程式碼給我，再接進 13u 的 `canPick()`。
- **驗證**：只做了語法檢查，未實機。
- **回復**：刪 13u 並移除 html／sw 的引用；11 `doPickoff` 與 05 的數字改回上述原值；sw.js 回 v1.1.35。

## 第四十五版（v1.1.37）：盜壘跑速加成＋傳球速度隨真實距離／情況變化（改 04／05／06／sw.js）
- **盜壘跑速（05）**：新增 `stealSpdK(pl)`＝`clamp(1+(spd-55)*.0045,.88,1.25)`，`updateRunners` 在 `r.stealer` 首次跑動時對 `r.spd` 只乘一次（跑速90≈8.0 m/s、55≈5.9、30≈4.7），所以 AI／ABS 用 `r.spd` 估算時也讀到同一個值；新增 `stealRampK(pl)`＝`clamp(1-(spd-55)*.012,.5,1)`，把 `stealRamp(r)`（定義在未上傳的檔案）的加速段縮短，跑速90 的加速段只剩 58%。跑速≤55 的加速段不變（避免回壘時 `accT=stealRamp(r)` 的「已加速完」設定不一致）。**注意**：`startSteal`／`stealRamp`／`effLead` 不在上傳檔裡（推測 07／11 以外），若 `startSteal` 已另外用跑速調過 `r.spd`，會變成雙重加成，請回報。
- **傳球速度（04／05／06）**：`armSpeed(pl, d)` 新增選用的距離參數，乘上 `throwDistK(d)`（`THROW_K` 表：0m .62、8m .72、16m .92、24m 1.0、40m 1.10、60m 1.18、85m 1.26，線性內插）。肩力60：8m .51s、25m 1.15s、38.8m(捕手傳二壘) 1.64s、55m 2.20s、80m 2.98s（舊：.37／1.16／1.80／2.55／3.70）。`throwTo` 的 `dur` 改用此函式並**移除外野手固定 ×.9**（改由距離倍率負責）；情況修正 `sit`：撲接後傳 ×.93＋.1s、邊跑邊傳（f.v>4）×.96、雨天 ×(1-rainK*.05)、轉傳雙殺 ×1.03 且出手快 .02s。`throwDur`／`ballETA`／`runnerArrive 前的 tBall`(06 `tagUpThink`)／夾殺傳球／06 的手動傳球與回傳，全部改帶入距離，AI 的判斷與實際傳球時間一致。06 傳球弧線高度改用實際傳球距離（原本用 dur×armSpeed，加入距離倍率後不再等於距離）。
- **影響**：近距離(<16m)傳球略慢、內野標準傳球(25m)幾乎不變、長傳(>40m)快約 8～20%，所以外野安打多跑壘、傳本壘的結果會略偏守備方；捕手傳二壘快約 .15 秒，會抵消一部分跑速加成。未經 harness 量測，請看盜壘成功率與外野安打進壘率，需要時調 `THROW_K`、`stealSpdK` 的 .0045。
- **驗證**：只做語法檢查與數值試算，未實機。
- **回復**：`armSpeed` 改回單參數、`throwTo` 的 `dur` 改回 `(d/armSpeed+.05)*ofk(.9 for OF)*…`、移除 `stealSpdK／stealRampK` 兩處使用、sw.js 回 v1.1.36。
